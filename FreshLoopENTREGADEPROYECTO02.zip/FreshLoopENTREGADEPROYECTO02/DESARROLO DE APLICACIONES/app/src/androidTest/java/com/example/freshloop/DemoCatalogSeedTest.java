package com.example.freshloop;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.Blob;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.WriteBatch;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RunWith(AndroidJUnit4.class)
public class DemoCatalogSeedTest {
    private static final String EMAIL = "negocio.super.foodloop+1791707512724@gmail.com";
    private static final String PASSWORD = "123456";
    private static final String UID = "I16YT1O9ieSwbJ4UtB2HQO18Nv43";

    private static final String[][] OFFERS = {
            {"torta_chocolate", "Torta de chocolate", "Postres", "Venta económica", "8.00", "15.00", "6", "Torta húmeda preparada durante el día, con ganache de chocolate."},
            {"combo_pollo", "Combo de pollo a la brasa", "Restaurantes", "Venta económica", "10.00", "20.00", "5", "Pollo dorado con papas y ensalada fresca, listo para recoger."},
            {"pan_artesanal", "Pan artesanal mixto", "Panadería", "Venta económica", "4.00", "8.00", "8", "Pan de masa madre con corteza crujiente y miga aireada."},
            {"croissants", "Croissants de mantequilla", "Panadería", "Donación", "0.00", "0.00", "5", "Croissants del día, hojaldrados y listos para compartir."},
            {"ensalada_gourmet", "Ensalada mixta gourmet", "Comida preparada", "Donación", "0.00", "0.00", "4", "Vegetales frescos, palta y semillas en una porción completa."},
            {"postres_variados", "Postres variados", "Otros", "Venta económica", "6.00", "12.00", "7", "Selección de tartaletas y pequeños postres del día."}
    };
    private static final String[] DATES = {"15-10-2026", "16-10-2026", "17-10-2026", "18-10-2026", "19-10-2026", "20-10-2026"};
    private static final String[] TIMES = {"18:30", "19:00", "20:00", "20:30", "18:00", "19:30"};

    @Test public void seedSixSparkFriendlyOffersWithCompressedPhotos() throws Exception {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.signOut();
        Tasks.await(auth.signInWithEmailAndPassword(EMAIL, PASSWORD), 60, TimeUnit.SECONDS);
        assertEquals(UID, auth.getUid());
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Context context = InstrumentationRegistry.getInstrumentation().getContext();

        Map<String, Object> business = new HashMap<>();
        business.put("descripcion", "Panadería y cocina local que rescata excedentes frescos cada tarde.");
        business.put("telefono", "+51 999 123 456");
        business.put("horario", "Lun-Sáb, 7:00 a.m. - 9:00 p.m.");
        Tasks.await(db.collection("businesses").document(UID).update(business), 30, TimeUnit.SECONDS);

        for (int offerIndex = 0; offerIndex < OFFERS.length; offerIndex++) {
            String[] offer = OFFERS[offerIndex];
            String slug = offer[0];
            String foodId = "demo_" + UID.substring(0, 6) + "_" + slug;
            String imageId = "food_" + foodId;
            Photo photo = compress(context, "demo_images/" + slug + ".png");
            assertTrue("La foto debe respetar 100 KiB", photo.bytes.length <= 102400);

            Map<String, Object> image = new HashMap<>();
            image.put("ownerUid", UID);
            image.put("entityType", "food");
            image.put("entityId", foodId);
            image.put("content", Blob.fromBytes(photo.bytes));
            image.put("mime", "image/jpeg");
            image.put("width", photo.width);
            image.put("height", photo.height);
            image.put("version", 1);
            image.put("updatedAt", FieldValue.serverTimestamp());

            Map<String, Object> food = new HashMap<>();
            food.put("name", offer[1]);
            food.put("category", offer[2]);
            food.put("type", offer[3]);
            food.put("price", offer[4]);
            food.put("originalPrice", offer[5]);
            food.put("quantity", Integer.parseInt(offer[6]));
            food.put("description", offer[7]);
            food.put("expiration", DATES[offerIndex]);
            food.put("pickupTime", TIMES[offerIndex]);
            food.put("address", "Av. Universitaria 123");
            food.put("zone", "Los Olivos");
            food.put("publisher", "Panadería Super QA");
            food.put("uidNegocio", UID);
            food.put("status", "Disponible");
            food.put("published", true);
            food.put("imageId", imageId);
            food.put("imageVersion", 1);

            WriteBatch batch = db.batch();
            DocumentReference imageRef = db.collection("images").document(imageId);
            DocumentReference foodRef = db.collection("foods").document(foodId);
            batch.set(imageRef, image);
            if (!Tasks.await(foodRef.get(), 30, TimeUnit.SECONDS).exists()) {
                food.put("fechaCreacion", FieldValue.serverTimestamp());
                batch.set(foodRef, food);
            }
            Tasks.await(batch.commit(), 30, TimeUnit.SECONDS);
            System.out.println("QA_DEMO_FOOD=" + foodId + " PHOTO_BYTES=" + photo.bytes.length);
        }
        assertEquals(6, OFFERS.length);
    }

    private Photo compress(Context context, String path) throws Exception {
        Bitmap source;
        try (InputStream input = context.getAssets().open(path)) {
            source = BitmapFactory.decodeStream(input);
        }
        int width = Math.min(640, source.getWidth());
        int height = Math.round(source.getHeight() * (width / (float) source.getWidth()));
        Bitmap scaled = Bitmap.createScaledBitmap(source, width, height, true);
        if (scaled != source) source.recycle();
        int quality = 72;
        byte[] bytes;
        do {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, output);
            bytes = output.toByteArray();
            quality -= 6;
        } while (bytes.length > 102400 && quality >= 30);
        int finalWidth = scaled.getWidth();
        int finalHeight = scaled.getHeight();
        scaled.recycle();
        return new Photo(bytes, finalWidth, finalHeight);
    }

    private static final class Photo {
        final byte[] bytes;
        final int width;
        final int height;
        Photo(byte[] bytes, int width, int height) {
            this.bytes = bytes;
            this.width = width;
            this.height = height;
        }
    }
}
