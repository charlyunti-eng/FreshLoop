package com.example.freshloop;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Crea datos QA deliberadamente persistentes y verifica su retención mediante
 * cierre de sesión y nueva autenticación. No elimina cuentas ni documentos.
 */
@RunWith(AndroidJUnit4.class)
public class FirebasePersistenceRetentionTest {
    private static final String PASSWORD = "123456";

    @Test
    public void createdDataSurvivesSignOutAndReauthentication() throws Exception {
        long stamp = System.currentTimeMillis();
        String businessEmail = "negocio.persistencia.foodloop+" + stamp + "@gmail.com";
        String clientEmail = "cliente.persistencia.foodloop+" + stamp + "@gmail.com";
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        auth.signOut();

        FirebaseUser businessUser = Tasks.await(
                auth.createUserWithEmailAndPassword(businessEmail, PASSWORD), 60, TimeUnit.SECONDS).getUser();
        assertNotNull(businessUser);
        String businessUid = businessUser.getUid();
        Tasks.await(FirebaseRepository.saveUser(businessUid, "Negocio Persistencia QA", businessEmail, "Negocio"), 30, TimeUnit.SECONDS);
        assertEquals(businessUid, Tasks.await(db.collection("users").document(businessUid).get(), 30, TimeUnit.SECONDS).getString("uid"));

        Map<String, Object> business = new HashMap<>();
        business.put("uidUsuario", businessUid);
        business.put("nombreNegocio", "Negocio Persistencia QA");
        business.put("direccion", "Av. Persistencia 123");
        business.put("zona", "Zona QA");
        business.put("telefono", "999 000 111");
        business.put("horario", "Lun-Sáb 08:00-20:00");
        Tasks.await(db.collection("businesses").document(businessUid).set(business), 30, TimeUnit.SECONDS);

        Map<String, Object> food = new HashMap<>();
        food.put("name", "Oferta Persistencia QA " + stamp);
        food.put("description", "Publicación de retención QA");
        food.put("quantity", 3);
        food.put("category", "Postres");
        food.put("expiration", "31-12-2099");
        food.put("pickupTime", "20:00");
        food.put("type", "Venta económica");
        food.put("price", "5.00");
        food.put("address", "Av. Persistencia 123");
        food.put("zone", "Zona QA");
        food.put("publisher", "Negocio Persistencia QA");
        food.put("uidNegocio", businessUid);
        food.put("status", "Disponible");
        food.put("published", true);
        food.put("fechaCreacion", FieldValue.serverTimestamp());
        DocumentReference foodRef = Tasks.await(db.collection("foods").add(food), 30, TimeUnit.SECONDS);
        String foodId = foodRef.getId();

        auth.signOut();
        Tasks.await(auth.signInWithEmailAndPassword(businessEmail, PASSWORD), 60, TimeUnit.SECONDS);
        assertTrue(Tasks.await(db.collection("businesses").document(businessUid).get(), 30, TimeUnit.SECONDS).exists());
        DocumentSnapshot persistedFood = Tasks.await(foodRef.get(), 30, TimeUnit.SECONDS);
        assertTrue(persistedFood.exists());
        assertEquals(true, persistedFood.getBoolean("published"));

        auth.signOut();
        FirebaseUser clientUser = Tasks.await(
                auth.createUserWithEmailAndPassword(clientEmail, PASSWORD), 60, TimeUnit.SECONDS).getUser();
        assertNotNull(clientUser);
        String clientUid = clientUser.getUid();
        Tasks.await(FirebaseRepository.saveUser(clientUid, "Cliente Persistencia QA", clientEmail, "Cliente"), 30, TimeUnit.SECONDS);
        assertEquals(clientUid, Tasks.await(db.collection("users").document(clientUid).get(), 30, TimeUnit.SECONDS).getString("uid"));

        DocumentReference reservationRef = Tasks.await(
                ReservationRepository.reserve(foodId, 1, "Cliente Persistencia QA"), 60, TimeUnit.SECONDS);
        String reservationId = reservationRef.getId();
        assertEquals("Confirmada", Tasks.await(reservationRef.get(), 30, TimeUnit.SECONDS).getString("estadoReserva"));

        auth.signOut();
        Tasks.await(auth.signInWithEmailAndPassword(clientEmail, PASSWORD), 60, TimeUnit.SECONDS);
        DocumentSnapshot persistedClient = Tasks.await(db.collection("users").document(clientUid).get(), 30, TimeUnit.SECONDS);
        assertTrue(persistedClient.exists());
        QuerySnapshot reservations = Tasks.await(
                db.collection("reservations").whereEqualTo("uidCliente", clientUid).get(), 30, TimeUnit.SECONDS);
        assertTrue(reservations.getDocuments().stream().anyMatch(d -> d.getId().equals(reservationId)));
        assertEquals("Confirmada", Tasks.await(reservationRef.get(), 30, TimeUnit.SECONDS).getString("estadoReserva"));
        assertTrue(Tasks.await(foodRef.get(), 30, TimeUnit.SECONDS).exists());

        System.out.println("PERSISTENCE_BUSINESS_EMAIL=" + businessEmail);
        System.out.println("PERSISTENCE_BUSINESS_UID=" + businessUid);
        System.out.println("PERSISTENCE_CLIENT_EMAIL=" + clientEmail);
        System.out.println("PERSISTENCE_CLIENT_UID=" + clientUid);
        System.out.println("PERSISTENCE_FOOD_ID=" + foodId);
        System.out.println("PERSISTENCE_RESERVATION_ID=" + reservationId);
        System.out.println("PERSISTENCE_FINAL_FOOD_STATUS=Disponible");
        System.out.println("PERSISTENCE_FINAL_RESERVATION_STATUS=Confirmada");
    }
}
