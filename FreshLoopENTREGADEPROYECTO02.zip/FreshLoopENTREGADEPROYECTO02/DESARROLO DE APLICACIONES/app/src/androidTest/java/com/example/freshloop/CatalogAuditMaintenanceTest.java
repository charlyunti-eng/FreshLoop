package com.example.freshloop;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.TimeUnit;

/** Mantenimiento acotado de la demo y evidencia del origen del catálogo. */
@RunWith(AndroidJUnit4.class)
public class CatalogAuditMaintenanceTest {
    private static final String EMAIL = "negocio.super.foodloop+1791707512724@gmail.com";
    private static final String PASSWORD = "123456";
    private static final String UID = "I16YT1O9ieSwbJ4UtB2HQO18Nv43";
    private static final String[] SLUGS = {"torta_chocolate", "combo_pollo", "pan_artesanal", "croissants", "ensalada_gourmet", "postres_variados"};
    private static final String[] DATES = {"15-10-2026", "16-10-2026", "17-10-2026", "18-10-2026", "19-10-2026", "20-10-2026"};
    private static final String[] TIMES = {"18:30", "19:00", "20:00", "20:30", "18:00", "19:30"};

    @Test public void correctOnlySixDemoDatesAndAuditEveryFood() throws Exception {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.signOut();
        Tasks.await(auth.signInWithEmailAndPassword(EMAIL, PASSWORD), 60, TimeUnit.SECONDS);
        assertEquals(UID, auth.getUid());
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        for (int i = 0; i < SLUGS.length; i++) {
            DocumentReference ref = db.collection("foods").document("demo_" + UID.substring(0, 6) + "_" + SLUGS[i]);
            DocumentSnapshot before = Tasks.await(ref.get(), 30, TimeUnit.SECONDS);
            assertTrue("Falta oferta demo " + SLUGS[i], before.exists());
            Timestamp createdAt = before.getTimestamp("fechaCreacion");
            assertNotNull("La oferta demo debe conservar fechaCreacion", createdAt);
            Tasks.await(ref.update("expiration", DATES[i], "pickupTime", TIMES[i], "published", true), 30, TimeUnit.SECONDS);
            DocumentSnapshot after = Tasks.await(ref.get(), 30, TimeUnit.SECONDS);
            assertEquals(createdAt, after.getTimestamp("fechaCreacion"));
            assertEquals(DATES[i], after.getString("expiration"));
            assertEquals(TIMES[i], after.getString("pickupTime"));
            System.out.println("QA_DEMO_CORRECTED id=" + ref.getId() + " expiration=" + DATES[i] + " pickup=" + TIMES[i] + " createdAt=" + createdAt);
        }

        QuerySnapshot all = Tasks.await(db.collection("foods").get(), 30, TimeUnit.SECONDS);
        int offerable = 0;
        java.util.Set<String> requiredDemoIds = new java.util.HashSet<>();
        for (DocumentSnapshot food : all.getDocuments()) {
            boolean visible = ReservationRepository.isOfferable(food);
            if (visible) offerable++;
            if (food.getId().startsWith("demo_" + UID.substring(0, 6) + "_")) requiredDemoIds.add(food.getId());
            System.out.println("QA_CATALOG_DOC id=" + food.getId()
                    + " owner=" + food.getString("uidNegocio")
                    + " name=" + food.getString("name")
                    + " status=" + food.getString("status")
                    + " stock=" + ReservationRepository.stock(food.get("quantity"))
                    + " published=" + food.getBoolean("published")
                    + " expiration=" + food.getString("expiration")
                    + " offerable=" + visible);
        }
        System.out.println("QA_CATALOG_TOTAL=" + all.size() + " QA_CATALOG_OFFERABLE=" + offerable);
        assertEquals("Deben estar presentes las seis ofertas demo requeridas", 6, requiredDemoIds.size());
        for (String slug : SLUGS) {
            assertTrue("Falta oferta demo visible " + slug,
                    requiredDemoIds.contains("demo_" + UID.substring(0, 6) + "_" + slug));
        }
    }
}
