package com.example.freshloop;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RunWith(AndroidJUnit4.class)
public class FirebaseEndToEndTest {
    private static final String PASSWORD = "123456";

    @Test public void fullFirebaseFlowWithUnitStockCancellationAndCompletion() throws Exception {
        long stamp = System.currentTimeMillis();
        String businessEmail = "negocio.super.foodloop+" + stamp + "@gmail.com";
        String clientEmail = "cliente.super.foodloop+" + stamp + "@gmail.com";
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        auth.signOut();

        FirebaseUser businessUser = Tasks.await(auth.createUserWithEmailAndPassword(businessEmail, PASSWORD), 30, TimeUnit.SECONDS).getUser();
        assertNotNull(businessUser);
        String businessUid = businessUser.getUid();
        Tasks.await(FirebaseRepository.saveUser(businessUid, "Negocio Super QA", businessEmail, "Negocio"), 30, TimeUnit.SECONDS);
        DocumentSnapshot businessProfile = Tasks.await(db.collection("users").document(businessUid).get(), 30, TimeUnit.SECONDS);
        assertEquals(businessUid, businessProfile.getString("uid"));
        assertEquals("Negocio", businessProfile.getString("tipoUsuario"));

        Map<String, Object> business = new HashMap<>();
        business.put("uidUsuario", businessUid);
        business.put("nombreNegocio", "Panadería Super QA");
        business.put("descripcion", "Excedentes frescos para la comunidad");
        business.put("direccion", "Av. Universitaria 123");
        business.put("zona", "Los Olivos");
        business.put("telefono", "999 123 456");
        business.put("horario", "Lun-Sáb, 7:00 a.m. - 9:00 p.m.");
        Tasks.await(db.collection("businesses").document(businessUid).set(business), 30, TimeUnit.SECONDS);

        Map<String, Object> food = new HashMap<>();
        food.put("name", "Torta Super QA");
        food.put("description", "Porciones disponibles del día");
        food.put("quantity", 5);
        food.put("category", "Postres");
        food.put("expiration", "31-10-2026");
        food.put("pickupTime", "21:00");
        food.put("type", "Venta económica");
        food.put("price", "5.00");
        food.put("originalPrice", "15.00");
        food.put("address", "Av. Universitaria 123");
        food.put("zone", "Los Olivos");
        food.put("publisher", "Panadería Super QA");
        food.put("uidNegocio", businessUid);
        food.put("status", "Disponible");
        food.put("published", true);
        food.put("fechaCreacion", FieldValue.serverTimestamp());
        DocumentReference foodRef = Tasks.await(db.collection("foods").add(food), 30, TimeUnit.SECONDS);
        Tasks.await(foodRef.update("quantity", 4, "price", "4.50"), 30, TimeUnit.SECONDS);
        DocumentSnapshot edited = Tasks.await(foodRef.get(), 30, TimeUnit.SECONDS);
        assertEquals(4L, edited.getLong("quantity").longValue());
        assertEquals("4.50", edited.getString("price"));

        auth.signOut();
        FirebaseUser clientUser = Tasks.await(auth.createUserWithEmailAndPassword(clientEmail, PASSWORD), 30, TimeUnit.SECONDS).getUser();
        assertNotNull(clientUser);
        String clientUid = clientUser.getUid();
        Tasks.await(FirebaseRepository.saveUser(clientUid, "Cliente Super QA", clientEmail, "Cliente"), 30, TimeUnit.SECONDS);
        DocumentSnapshot clientProfile = Tasks.await(db.collection("users").document(clientUid).get(), 30, TimeUnit.SECONDS);
        assertEquals(clientUid, clientProfile.getString("uid"));
        assertEquals("Cliente", clientProfile.getString("tipoUsuario"));

        Tasks.await(FavoriteRepository.add(foodRef.getId()), 30, TimeUnit.SECONDS);
        assertTrue(Tasks.await(db.collection("users").document(clientUid).collection("favorites").document(foodRef.getId()).get(), 30, TimeUnit.SECONDS).exists());
        Tasks.await(FavoriteRepository.remove(foodRef.getId()), 30, TimeUnit.SECONDS);
        assertTrue(!Tasks.await(db.collection("users").document(clientUid).collection("favorites").document(foodRef.getId()).get(), 30, TimeUnit.SECONDS).exists());

        QuerySnapshot postres = Tasks.await(db.collection("foods").whereEqualTo("category", "Postres").get(), 30, TimeUnit.SECONDS);
        assertTrue(postres.getDocuments().stream().anyMatch(d -> d.getId().equals(foodRef.getId())));

        DocumentReference cancelledRef = Tasks.await(ReservationRepository.reserve(foodRef.getId(), 2, "Cliente Super QA"), 30, TimeUnit.SECONDS);
        DocumentSnapshot afterReserve = Tasks.await(foodRef.get(), 30, TimeUnit.SECONDS);
        assertEquals(2L, afterReserve.getLong("quantity").longValue());
        assertEquals("Disponible", afterReserve.getString("status"));
        DocumentSnapshot firstReservation = Tasks.await(cancelledRef.get(), 30, TimeUnit.SECONDS);
        assertEquals("Confirmada", firstReservation.getString("estadoReserva"));
        assertEquals(2L, firstReservation.getLong("quantityReserved").longValue());
        assertEquals(900L, firstReservation.getLong("totalCents").longValue());

        boolean duplicateBlocked = false;
        try {
            Tasks.await(ReservationRepository.reserve(foodRef.getId(), 1, "Cliente Super QA"), 30, TimeUnit.SECONDS);
        } catch (Exception expected) {
            duplicateBlocked = true;
        }
        assertTrue("La guarda debe impedir dos reservas activas del mismo alimento", duplicateBlocked);

        Tasks.await(ReservationRepository.cancel(cancelledRef.getId()), 30, TimeUnit.SECONDS);
        assertEquals("Cancelada", Tasks.await(cancelledRef.get(), 30, TimeUnit.SECONDS).getString("estadoReserva"));
        assertEquals(4L, Tasks.await(foodRef.get(), 30, TimeUnit.SECONDS).getLong("quantity").longValue());

        DocumentReference completedRef = Tasks.await(ReservationRepository.reserve(foodRef.getId(), 1, "Cliente Super QA"), 30, TimeUnit.SECONDS);
        assertEquals(3L, Tasks.await(foodRef.get(), 30, TimeUnit.SECONDS).getLong("quantity").longValue());
        auth.signOut();
        Tasks.await(auth.signInWithEmailAndPassword(businessEmail, PASSWORD), 30, TimeUnit.SECONDS);
        Tasks.await(ReservationRepository.complete(completedRef.getId()), 30, TimeUnit.SECONDS);
        assertEquals("Completada", Tasks.await(completedRef.get(), 30, TimeUnit.SECONDS).getString("estadoReserva"));
        assertEquals(3L, Tasks.await(foodRef.get(), 30, TimeUnit.SECONDS).getLong("quantity").longValue());

        QuerySnapshot received = Tasks.await(db.collection("reservations").whereEqualTo("uidNegocio", businessUid).get(), 30, TimeUnit.SECONDS);
        assertEquals(2, received.size());
        Boolean guardActive = Tasks.await(db.collection("reservationGuards").document(clientUid + "_" + foodRef.getId()).get(), 30, TimeUnit.SECONDS).getBoolean("active");
        if (Boolean.TRUE.equals(guardActive)) fail("La guarda debe quedar inactiva al completar la entrega");

        System.out.println("QA_BUSINESS_EMAIL=" + businessEmail);
        System.out.println("QA_CLIENT_EMAIL=" + clientEmail);
        System.out.println("QA_BUSINESS_UID=" + businessUid);
        System.out.println("QA_CLIENT_UID=" + clientUid);
        System.out.println("QA_FOOD_ID=" + foodRef.getId());
        System.out.println("QA_CANCELLED_RESERVATION_ID=" + cancelledRef.getId());
        System.out.println("QA_COMPLETED_RESERVATION_ID=" + completedRef.getId());
    }
}
