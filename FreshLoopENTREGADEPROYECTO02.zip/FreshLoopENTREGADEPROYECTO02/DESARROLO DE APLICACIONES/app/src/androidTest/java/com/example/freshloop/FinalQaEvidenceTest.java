package com.example.freshloop;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.content.ClipboardManager;
import android.content.Context;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.TimeUnit;

@RunWith(AndroidJUnit4.class)
public class FinalQaEvidenceTest {
    @Test public void knownCoordinatesUseHaversineDistance() {
        assertEquals(111.2, GeoUtils.distanceKm(0, 0, 1, 0), 1.0);
        assertTrue(GeoUtils.label(1.234).contains("1.2 km aprox."));
    }

    @Test public void copyReceiptCodeCanBeReadByClipboardManager() throws Exception {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) return;
        String uid = auth.getCurrentUser().getUid();
        com.google.firebase.firestore.QuerySnapshot snapshot = Tasks.await(
                FirebaseFirestore.getInstance().collection("reservations").whereEqualTo("uidCliente", uid).limit(1).get(), 30, TimeUnit.SECONDS);
        if (snapshot.isEmpty()) return;
        String code = snapshot.getDocuments().get(0).getString("codigo");
        if (code == null || code.isEmpty()) return;
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        ReservationSuccessActivity.copyCode(context, code);
        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        assertEquals(code, clipboard.getPrimaryClip().getItemAt(0).getText().toString());
    }
}
