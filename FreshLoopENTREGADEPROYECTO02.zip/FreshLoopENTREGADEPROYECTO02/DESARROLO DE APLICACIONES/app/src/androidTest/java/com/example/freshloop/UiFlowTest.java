package com.example.freshloop;

import static androidx.test.espresso.Espresso.*;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.*;
import static org.hamcrest.Matchers.*;

import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class UiFlowTest {
    private static final String BUSINESS="negocio.super.foodloop+1791707512724@gmail.com";
    private static final String CLIENT="cliente.super.foodloop+1791707512724@gmail.com";
    private static final String PASSWORD="123456";
    private static final String FOOD_ID="demo_I16YT1_torta_chocolate";
    private static final String FOOD_NAME="Torta de chocolate";

    private void waitUntilAdapterContains(int listId, String expected) {
        for (int attempt = 0; attempt < 30; attempt++) {
            AtomicBoolean found = new AtomicBoolean(false);
            onView(withId(listId)).check((view, noViewException) -> {
                if (noViewException != null) return;
                ListAdapter adapter = ((ListView) view).getAdapter();
                if (adapter == null) return;
                for (int i = 0; i < adapter.getCount(); i++) {
                    Object item = adapter.getItem(i);
                    if (item != null && item.toString().contains(expected)) {
                        found.set(true);
                        return;
                    }
                }
            });
            if (found.get()) return;
            SystemClock.sleep(1000);
        }
        throw new AssertionError("No apareció '" + expected + "' en la lista " + listId);
    }

    private void waitUntilTextContains(int viewId, String expected) {
        for (int attempt = 0; attempt < 30; attempt++) {
            AtomicBoolean found = new AtomicBoolean(false);
            onView(withId(viewId)).check((view, noViewException) -> {
                if (noViewException == null && ((TextView) view).getText().toString().contains(expected)) {
                    found.set(true);
                }
            });
            if (found.get()) return;
            SystemClock.sleep(1000);
        }
        throw new AssertionError("No apareció '" + expected + "' en la vista " + viewId);
    }

    @Test public void businessAndClientScreens() throws Exception {
        Context context=ApplicationProvider.getApplicationContext(); FirebaseAuth auth=FirebaseAuth.getInstance(); auth.signOut();
        Tasks.await(auth.signInWithEmailAndPassword(BUSINESS,PASSWORD),60,TimeUnit.SECONDS);
        com.google.firebase.firestore.DocumentSnapshot seededFood=Tasks.await(FirebaseFirestore.getInstance().collection("foods").document(FOOD_ID).get(),30,TimeUnit.SECONDS);
        String expectedQuantity=String.valueOf(ReservationRepository.stock(seededFood.get("quantity")));
        context.getSharedPreferences("usuario",Context.MODE_PRIVATE).edit().putString("nombre","Negocio Super QA").putString("tipo","Negocio").commit();
        try(ActivityScenario<HomeActivity> scenarioBusiness=ActivityScenario.launch(HomeActivity.class)){
            onView(withId(R.id.btnPublicar)).check(matches(isDisplayed()));onView(withId(R.id.btnNegocio)).check(matches(isDisplayed()));onView(withId(R.id.btnRecibidas)).check(matches(isDisplayed()));onView(withId(R.id.btnHistorial)).check(matches(withEffectiveVisibility(Visibility.GONE)));
            onView(withId(R.id.btnNegocio)).perform(click());SystemClock.sleep(2000);onView(withId(R.id.etBusinessName)).check(matches(withText("Panadería Super QA")));onView(withId(R.id.etBusinessAddress)).check(matches(withText("Av. Universitaria 123")));onView(withId(R.id.etBusinessZone)).check(matches(withText("Los Olivos")));onView(withId(R.id.btnSaveBusiness)).check(matches(withText("Actualizar negocio")));pressBack();
            waitUntilAdapterContains(R.id.lvAlimentos,FOOD_NAME);
            scenarioBusiness.onActivity(activity -> activity.startActivity(new Intent(activity, EditFoodActivity.class).putExtra("food_doc_id", FOOD_ID)));
            SystemClock.sleep(1500);onView(withId(R.id.etEditCantidad)).check(matches(withText(expectedQuantity)));onView(withId(R.id.etEditPrecio)).check(matches(withText("8.00")));onView(withId(R.id.etEditFecha)).check(matches(withText("15-10-2026")));
            pressBack();onView(withId(R.id.btnRecibidas)).perform(click());waitUntilAdapterContains(R.id.lvRecords,"Torta Super QA");onData(containsString("Torta Super QA")).inAdapterView(withId(R.id.lvRecords)).atPosition(0).check(matches(isDisplayed()));pressBack();
        }
        auth.signOut();Tasks.await(auth.signInWithEmailAndPassword(CLIENT,PASSWORD),60,TimeUnit.SECONDS);
        context.getSharedPreferences("usuario",Context.MODE_PRIVATE).edit().putString("nombre","Cliente Super QA").putString("tipo","Cliente").commit();
        try(ActivityScenario<HomeActivity> scenarioClient=ActivityScenario.launch(HomeActivity.class)){
            onView(withId(R.id.btnPublicar)).check(matches(withEffectiveVisibility(Visibility.GONE)));onView(withId(R.id.btnNegocio)).check(matches(withEffectiveVisibility(Visibility.GONE)));onView(withId(R.id.btnRecibidas)).check(matches(withEffectiveVisibility(Visibility.GONE)));onView(withId(R.id.btnHistorial)).check(matches(isDisplayed()));
            waitUntilAdapterContains(R.id.lvAlimentos,FOOD_NAME);onView(withId(R.id.spFiltroCategoria)).perform(click());onData(allOf(is(instanceOf(String.class)),is("Postres"))).perform(click());waitUntilAdapterContains(R.id.lvAlimentos,FOOD_NAME);onData(containsString(FOOD_NAME)).inAdapterView(withId(R.id.lvAlimentos)).check(matches(isDisplayed()));
            onView(withId(R.id.spFiltroCategoria)).perform(click());onData(allOf(is(instanceOf(String.class)),is("Todos"))).perform(click());waitUntilAdapterContains(R.id.lvAlimentos,FOOD_NAME);
            scenarioClient.onActivity(activity -> activity.startActivity(new Intent(activity, DetailFoodActivity.class).putExtra("food_doc_id", FOOD_ID)));SystemClock.sleep(1500);
            waitUntilTextContains(R.id.tvDetalleCantidad,"Cantidad: " + expectedQuantity);
            onView(withId(R.id.tvDetalleCantidad)).check(matches(withText("Cantidad: " + expectedQuantity)));onView(withId(R.id.tvDetalleCategoria)).check(matches(withText("Categoría: Postres")));onView(withId(R.id.tvDetalleFecha)).check(matches(withText("Vence: 15-10-2026")));onView(withId(R.id.tvDetallePrecio)).check(matches(withText("Precio: S/ 8.00")));onView(withId(R.id.tvUbicacionDireccion)).check(matches(withText(containsString("Av. Universitaria 123"))));onView(withId(R.id.tvDetalleEstado)).check(matches(withText("Estado: Disponible")));onView(withId(R.id.btnReservar)).check(matches(isEnabled()));
            pressBack();onView(withId(R.id.btnHistorial)).perform(click());waitUntilAdapterContains(R.id.lvRecords,"Torta Super QA");onData(containsString("Torta Super QA")).inAdapterView(withId(R.id.lvRecords)).atPosition(0).check(matches(isDisplayed()));pressBack();
        }
        try(ActivityScenario<MainActivity> ignored=ActivityScenario.launch(new Intent(context,MainActivity.class))){SystemClock.sleep(2500);onView(withText(containsString("Cliente Super QA"))).check(matches(isDisplayed()));}
    }
}
