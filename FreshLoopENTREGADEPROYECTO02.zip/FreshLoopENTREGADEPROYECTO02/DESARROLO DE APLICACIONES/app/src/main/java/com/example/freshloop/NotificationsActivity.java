package com.example.freshloop;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {
    private final List<SimpleCardAdapter.Item> items = new ArrayList<>();
    private ListView list;
    private TextView empty;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_simple_list);
        ((TextView) findViewById(R.id.tvSimpleTitle)).setText("Notificaciones");
        ((TextView) findViewById(R.id.tvSimpleSubtitle)).setText("Eventos reales de tus reservas");
        findViewById(R.id.btnBackSimple).setOnClickListener(v -> finish());
        list = findViewById(R.id.lvSimple); empty = findViewById(R.id.tvSimpleEmpty);
        empty.setText("No tienes actividad de reservas todavía.");
        load();
    }

    private void load() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { finish(); return; }
        String role = getSharedPreferences("usuario", MODE_PRIVATE).getString("tipo", "Cliente");
        String field = "Negocio".equals(role) ? "uidNegocio" : "uidCliente";
        FirebaseFirestore.getInstance().collection("reservations").whereEqualTo(field, uid).get()
                .addOnSuccessListener(snapshot -> {
                    items.clear();
                    for (DocumentSnapshot reservation : snapshot.getDocuments()) {
                        String food = reservation.getString("nombreAlimento");
                        String status = reservation.getString("estadoReserva");
                        Date date = reservation.getTimestamp("fechaReserva") == null ? null : reservation.getTimestamp("fechaReserva").toDate();
                        String when = date == null ? "Fecha pendiente" : DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(date);
                        String title = "Negocio".equals(role) ? "Reserva de " + safe(reservation.getString("nombreCliente")) : "Reserva " + safe(status).toLowerCase();
                        items.add(new SimpleCardAdapter.Item(title, safe(food) + " · " + safe(status) + "\n" + when));
                    }
                    list.setAdapter(new SimpleCardAdapter(this, items));
                    empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                    getSharedPreferences("notification_reads_" + uid, MODE_PRIVATE).edit().putLong("lastOpened", System.currentTimeMillis()).apply();
                }).addOnFailureListener(e -> Toast.makeText(this, "No se pudieron cargar las notificaciones", Toast.LENGTH_LONG).show());
    }
    private String safe(String value) { return value == null ? "" : value; }
}
