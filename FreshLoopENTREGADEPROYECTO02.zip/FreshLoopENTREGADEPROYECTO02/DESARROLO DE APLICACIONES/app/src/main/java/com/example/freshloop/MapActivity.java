package com.example.freshloop;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import android.os.Looper;
import android.os.Handler;
import android.util.Log;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;

import org.json.JSONArray;
import org.json.JSONObject;

public class MapActivity extends AppCompatActivity {
    private static final String MAP_URL = "https://appassets.androidplatform.net/assets/map/map.html";
    private WebView webView;
    private JSONArray businesses = new JSONArray();
    private boolean pageReady;
    private Location clientLocation;
    private LocationListener locationListener;
    private Location networkCandidate;
    private LocationManager activeLocationManager;
    private final Handler locationHandler = new Handler(Looper.getMainLooper());
    private static final String TAG = "FreshLoopLocation";

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_map);
        findViewById(R.id.btnBackMap).setOnClickListener(v -> finish());
        findViewById(R.id.btnRetryMap).setOnClickListener(v -> loadMap());
        NavigationHelper.setup(this, (BottomNavigationView) findViewById(R.id.bottomNavigation), R.id.nav_map);
        webView = findViewById(R.id.webMap);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setUserAgentString(webView.getSettings().getUserAgentString() + " FreshLoop/1.0");
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public void onPageFinished(WebView view, String url) { pageReady = true; render(); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("appassets.androidplatform.net".equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme())) startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
        });
        webView.addJavascriptInterface(new MapBridge(), "FreshLoopMap");
        loadMap();
        requestClientLocation();
    }

    private void requestClientLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 41);
            return;
        }
        try {
            LocationManager manager = (LocationManager) getSystemService(LOCATION_SERVICE);
            activeLocationManager = manager;
            networkCandidate = null;
            stopLocationUpdates(manager);
            ((TextView) findViewById(R.id.tvMapSubtitle)).setText("Esperando ubicación nueva…");
            locationListener = value -> {
                long age = Math.max(0L, System.currentTimeMillis() - value.getTime());
                Log.i(TAG, "provider=" + value.getProvider() + " lat=" + value.getLatitude() + " lon=" + value.getLongitude() + " accuracy=" + value.getAccuracy() + " timestamp=" + value.getTime() + " ageMs=" + age);
                if (age > 120000L) return;
                if (LocationManager.GPS_PROVIDER.equals(value.getProvider())) {
                    clientLocation = value;
                    Log.i(TAG, "acceptedProvider=gps");
                    stopLocationUpdates(manager);
                    ((TextView) findViewById(R.id.tvMapSubtitle)).setText("Tu ubicación detectada · puntos cercanos aproximados");
                    loadMap();
                } else {
                    networkCandidate = value;
                    Log.i(TAG, "networkCandidateStored=true waitingForGps=true");
                    ((TextView) findViewById(R.id.tvMapSubtitle)).setText("Buscando ubicación GPS…");
                }
            };
            for (String provider : manager.getProviders(true)) manager.requestLocationUpdates(provider, 0L, 0f, locationListener, Looper.getMainLooper());
            locationHandler.postDelayed(() -> {
                if (clientLocation == null) {
                    stopLocationUpdates(manager);
                    if (networkCandidate != null) {
                        clientLocation = networkCandidate;
                        Log.w(TAG, "gpsTimeout=true acceptedProvider=networkFallback");
                        ((TextView) findViewById(R.id.tvMapSubtitle)).setText("Ubicación aproximada detectada · puntos cercanos");
                        loadMap();
                    } else {
                        Log.w(TAG, "No se recibió una ubicación nueva dentro del tiempo de espera");
                        ((TextView) findViewById(R.id.tvMapSubtitle)).setText("No se recibió ubicación nueva · mapa disponible sin cercanía");
                    }
                }
            }, 12000L);
        } catch (SecurityException ignored) { }
    }

    private void stopLocationUpdates(LocationManager manager) {
        if (locationListener != null) {
            try { manager.removeUpdates(locationListener); Log.i(TAG, "removeUpdates called"); } catch (SecurityException ignored) { Log.w(TAG, "removeUpdates denied"); }
            locationListener = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 41 && grantResults.length > 0 && (grantResults[0] == PackageManager.PERMISSION_GRANTED || (grantResults.length > 1 && grantResults[1] == PackageManager.PERMISSION_GRANTED))) requestClientLocation();
        else ((TextView) findViewById(R.id.tvMapSubtitle)).setText("Ubicación no concedida · mapa disponible sin cercanía");
    }

    private void loadMap() {
        pageReady = false;
        findViewById(R.id.progressMap).setVisibility(View.VISIBLE);
        findViewById(R.id.panelMapError).setVisibility(View.GONE);
        webView.loadUrl(MAP_URL);
        String focusUid = getIntent().getStringExtra("business_uid");
        com.google.android.gms.tasks.Task<com.google.firebase.firestore.QuerySnapshot> query = focusUid == null
                ? FirebaseFirestore.getInstance().collection("businesses").get()
                : FirebaseFirestore.getInstance().collection("businesses").whereEqualTo("uidUsuario", focusUid).get();
        query.addOnSuccessListener(snapshot -> {
            businesses = new JSONArray();
            for (DocumentSnapshot business : snapshot.getDocuments()) {
                try {
                    GeoPoint point = business.getGeoPoint("location");
                    boolean confirmed = point != null && Boolean.TRUE.equals(business.getBoolean("locationConfirmed"));
                    if (!confirmed) continue;
                    JSONObject item = new JSONObject();
                    item.put("id", business.getId());
                    item.put("name", safe(business.getString("nombreNegocio"), "Negocio FreshLoop"));
                    item.put("address", safe(business.getString("direccion"), "Dirección no registrada"));
                    item.put("zone", safe(business.getString("zona"), "Sin zona"));
                    item.put("lat", point.getLatitude()); item.put("lng", point.getLongitude()); item.put("demo", false);
                    if (clientLocation != null) item.put("distance", GeoUtils.label(GeoUtils.distanceKm(clientLocation.getLatitude(), clientLocation.getLongitude(), point.getLatitude(), point.getLongitude())));
                    businesses.put(item);
                } catch (Exception ignored) { }
            }
            render();
        }).addOnFailureListener(e -> showError());
    }

    private void render() {
        if (!pageReady || webView == null) return;
        JSONObject encoded = new JSONObject();
        try { encoded.put("payload", businesses.toString()); } catch (Exception ignored) { }
        String script = "window.renderBusinesses(" + JSONObject.quote(businesses.toString()) + ")";
        webView.evaluateJavascript(script, null);
    }

    private void showError() { findViewById(R.id.progressMap).setVisibility(View.GONE); findViewById(R.id.panelMapError).setVisibility(View.VISIBLE); }
    private String safe(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value; }

    private final class MapBridge {
        @JavascriptInterface public void onMapReady(int count) { runOnUiThread(() -> { findViewById(R.id.progressMap).setVisibility(View.GONE); if (clientLocation == null) ((TextView) findViewById(R.id.tvMapSubtitle)).setText(count + (count == 1 ? " punto de recojo" : " puntos de recojo") + " · ubicación no disponible"); }); }
        @JavascriptInterface public void onMapError() { runOnUiThread(MapActivity.this::showError); }
        @JavascriptInterface public void openBusiness(String uid) { runOnUiThread(() -> startActivity(new Intent(MapActivity.this, PublicBusinessActivity.class).putExtra("business_uid", uid))); }
    }

    @Override protected void onDestroy() { stopLocationUpdates((LocationManager) getSystemService(LOCATION_SERVICE)); locationHandler.removeCallbacksAndMessages(null); if (webView != null) { webView.removeJavascriptInterface("FreshLoopMap"); webView.destroy(); } super.onDestroy(); }
}
