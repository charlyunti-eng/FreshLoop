package com.example.freshloop;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class StatisticsActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_statistics);
        findViewById(R.id.btnBackStats).setOnClickListener(v -> finish());
        String uid = FirebaseAuth.getInstance().getUid(); if (uid == null) { finish(); return; }
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("foods").whereEqualTo("uidNegocio", uid).get().addOnSuccessListener(s -> set(R.id.tvStatsFoods, s.size()));
        db.collection("reservations").whereEqualTo("uidNegocio", uid).get().addOnSuccessListener(s -> {
            int completed = 0, units = 0;
            for (DocumentSnapshot d : s.getDocuments()) if ("Completada".equals(d.getString("estadoReserva"))) {
                completed++; Number quantity = (Number) d.get("quantityReserved"); units += quantity == null ? 1 : quantity.intValue();
            }
            set(R.id.tvStatsReservations, s.size()); set(R.id.tvStatsCompleted, completed); set(R.id.tvStatsUnits, units);
        });
    }
    private void set(int id, int value) { ((TextView) findViewById(id)).setText(String.valueOf(value)); }
}
