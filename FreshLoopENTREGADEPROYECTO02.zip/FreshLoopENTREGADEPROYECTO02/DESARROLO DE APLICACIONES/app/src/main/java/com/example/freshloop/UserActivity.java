package com.example.freshloop;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.ImageView;
import android.content.res.ColorStateList;
import androidx.appcompat.app.AlertDialog;
import android.view.LayoutInflater;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.graphics.Typeface;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;

public class UserActivity extends AppCompatActivity {
    private EditText name, email, password;
    private Spinner role;
    private ProgressBar progress;
    private boolean registerMode;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        name = findViewById(R.id.etNombreUsuario);
        email = findViewById(R.id.etCorreo);
        password = findViewById(R.id.etContrasena);
        role = findViewById(R.id.spTipoUsuario);
        progress = findViewById(R.id.progressAuth);
        role.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Selecciona tipo", "Cliente", "Negocio"}));
        findViewById(R.id.btnRoleCliente).setOnClickListener(v -> selectRole(1));
        findViewById(R.id.btnRoleNegocio).setOnClickListener(v -> selectRole(2));
        findViewById(R.id.btnLogin).setOnClickListener(v -> login());
        findViewById(R.id.btnContinuar).setOnClickListener(v -> register());
        findViewById(R.id.btnBackAuth).setOnClickListener(v -> finish());
        ((android.widget.CheckBox)findViewById(R.id.cbShowPassword)).setOnCheckedChangeListener((button, checked) -> { password.setTransformationMethod(checked ? HideReturnsTransformationMethod.getInstance() : PasswordTransformationMethod.getInstance()); password.setSelection(password.length()); });
        findViewById(R.id.btnForgotPassword).setOnClickListener(v -> resetPassword());
        registerMode = "register".equals(getIntent().getStringExtra("auth_mode"));
        findViewById(R.id.btnSwitchAuth).setOnClickListener(v -> { registerMode = !registerMode; configureMode(); });
        configureMode();
    }

    private void selectRole(int position) {
        role.setSelection(position);
        updateRoleButtons();
    }

    private void updateRoleButtons() {
        int selectedPosition = role.getSelectedItemPosition();
        boolean client = selectedPosition == 1;
        boolean business = selectedPosition == 2;
        LinearLayout clientButton = findViewById(R.id.btnRoleCliente);
        LinearLayout businessButton = findViewById(R.id.btnRoleNegocio);
        clientButton.setBackgroundResource(client ? R.drawable.fresh_button_primary : R.drawable.fresh_role_unselected);
        businessButton.setBackgroundResource(business ? R.drawable.fresh_button_primary : R.drawable.fresh_role_unselected);
        int selected = getColor(R.color.white);
        int unselected = getColor(R.color.fresh_green_dark);
        setRoleTextColor(clientButton, client ? selected : unselected);
        setRoleTextColor(businessButton, business ? selected : unselected);
    }

    private void setRoleTextColor(LinearLayout container, int color) {
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child instanceof TextView) ((TextView) child).setTextColor(color);
            if (child instanceof ImageView) ((ImageView) child).setImageTintList(ColorStateList.valueOf(color));
        }
    }

    private void configureMode() {
        TextView title = findViewById(R.id.tvAuthTitle);
        TextView subtitle = findViewById(R.id.tvAuthSubtitle);
        TextView cardTitle = findViewById(R.id.tvAuthCardTitle);
        name.setVisibility(registerMode ? View.VISIBLE : View.GONE);
        findViewById(R.id.groupRole).setVisibility(View.VISIBLE);
        findViewById(R.id.btnContinuar).setVisibility(registerMode ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnLogin).setVisibility(registerMode ? View.GONE : View.VISIBLE);
        findViewById(R.id.btnForgotPassword).setVisibility(registerMode ? View.GONE : View.VISIBLE);
        title.setText(registerMode ? "Crea tu cuenta" : "Bienvenido de nuevo");
        subtitle.setText(registerMode ? "Únete a FreshLoop y comienza a aprovechar alimentos disponibles cerca de ti." : "Ingresa para encontrar ofertas, gestionar reservas o administrar tu negocio.");
        cardTitle.setText(registerMode ? "Datos de tu cuenta" : "Accede a tu cuenta");
        updateSwitchLabel();
        updateRoleButtons();
    }

    private void updateSwitchLabel() {
        String prefix = registerMode ? "¿Ya tienes cuenta? " : "¿No tienes cuenta? ";
        String action = registerMode ? "Inicia sesión" : "Crear cuenta";
        SpannableString label = new SpannableString(prefix + action);
        label.setSpan(new ForegroundColorSpan(getColor(R.color.fresh_text_secondary)), 0, prefix.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        label.setSpan(new ForegroundColorSpan(getColor(R.color.fresh_green_primary)), prefix.length(), label.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        label.setSpan(new StyleSpan(Typeface.BOLD), prefix.length(), label.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ((Button) findViewById(R.id.btnSwitchAuth)).setText(label);
    }

    private void login() {
        String mail = text(email), pass = password.getText().toString();
        if (mail.isEmpty()) { email.setError("Correo obligatorio"); return; }
        if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) { email.setError("Correo no válido"); return; }
        if (pass.isEmpty()) { password.setError("Contraseña obligatoria"); return; }
        String selectedRole = role.getSelectedItemPosition() == 0 ? "" : role.getSelectedItem().toString();
        if (selectedRole.isEmpty()) { Toast.makeText(this, "Selecciona Cliente o Negocio", Toast.LENGTH_SHORT).show(); return; }
        busy(true);
        FirebaseRepository.auth().signInWithEmailAndPassword(mail, pass).addOnCompleteListener(task -> {
            if (!task.isSuccessful()) { busy(false); Toast.makeText(this, "Correo o contraseña incorrectos", Toast.LENGTH_LONG).show(); return; }
            FirebaseUser current = FirebaseRepository.auth().getCurrentUser();
            if (current == null) { busy(false); return; }
            FirebaseRepository.getUser(current.getUid()).addOnCompleteListener(profileTask -> {
                busy(false);
                if (!profileTask.isSuccessful() || profileTask.getResult() == null || !profileTask.getResult().exists()) {
                    Toast.makeText(this, "Perfil no encontrado. Regístrate nuevamente.", Toast.LENGTH_LONG).show();
                    FirebaseRepository.auth().signOut(); return;
                }
                route(profileTask.getResult(), selectedRole);
            });
        });
    }

    private void register() {
        String userName = text(name), mail = text(email), pass = password.getText().toString();
        String selectedRole = role.getSelectedItemPosition() == 0 ? "" : role.getSelectedItem().toString();
        if (userName.isEmpty()) { name.setError("Nombre obligatorio"); return; }
        if (mail.isEmpty()) { email.setError("Correo obligatorio"); return; }
        if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) { email.setError("Correo no válido"); return; }
        if (pass.isEmpty()) { password.setError("Contraseña obligatoria"); return; }
        if (pass.length() < 6) { password.setError("Mínimo 6 caracteres"); return; }
        if (selectedRole.isEmpty()) { Toast.makeText(this, "Selecciona Cliente o Negocio", Toast.LENGTH_SHORT).show(); return; }
        busy(true);
        FirebaseRepository.auth().createUserWithEmailAndPassword(mail, pass).addOnCompleteListener(task -> {
            if (!task.isSuccessful()) { busy(false); Toast.makeText(this, "No se pudo registrar: " + task.getException().getMessage(), Toast.LENGTH_LONG).show(); return; }
            FirebaseUser current = FirebaseRepository.auth().getCurrentUser();
            if (current == null) { busy(false); return; }
            FirebaseRepository.saveUser(current.getUid(), userName, mail, selectedRole).addOnCompleteListener(save -> {
                busy(false);
                if (!save.isSuccessful()) { Toast.makeText(this, "No se pudo guardar el perfil", Toast.LENGTH_LONG).show(); return; }
                saveSession(userName, selectedRole);
                startActivity(new Intent(this, HomeActivity.class)); finish();
            });
        });
    }

    private void route(DocumentSnapshot profile, String selectedRole) {
        String userName = profile.getString("nombre");
        String type = profile.getString("tipoUsuario");
        if (userName == null || type == null || (!type.equals("Cliente") && !type.equals("Negocio"))) {
            Toast.makeText(this, "Perfil incompleto", Toast.LENGTH_LONG).show(); FirebaseRepository.auth().signOut(); return;
        }
        if (!type.equals(selectedRole)) { Toast.makeText(this, "Esta cuenta está registrada como " + type + ". Selecciona ese perfil para ingresar.", Toast.LENGTH_LONG).show(); FirebaseRepository.auth().signOut(); return; }
        saveSession(userName, type);
        startActivity(new Intent(this, HomeActivity.class)); finish();
    }
    private void resetPassword() {
        View content = LayoutInflater.from(this).inflate(R.layout.dialog_reset_password, null, false);
        EditText dialogEmail = content.findViewById(R.id.dialogResetEmail);
        Button cancel = content.findViewById(R.id.btnResetCancel);
        Button send = content.findViewById(R.id.btnResetSend);
        ProgressBar dialogProgress = content.findViewById(R.id.progressReset);
        String current = text(email);
        if (Patterns.EMAIL_ADDRESS.matcher(current).matches()) dialogEmail.setText(current);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        cancel.setOnClickListener(v -> dialog.dismiss());
        send.setOnClickListener(v -> {
            String mail = text(dialogEmail);
            if (mail.isEmpty()) { dialogEmail.setError("Correo obligatorio"); return; }
            if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) { dialogEmail.setError("Correo no válido"); return; }
            send.setEnabled(false); cancel.setEnabled(false); dialogProgress.setVisibility(View.VISIBLE);
            FirebaseRepository.auth().sendPasswordResetEmail(mail).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    dialog.dismiss();
                    Toast.makeText(this, "Si el correo está registrado, recibirás un enlace de recuperación. Revisa también la carpeta de spam.", Toast.LENGTH_LONG).show();
                } else {
                    send.setEnabled(true); cancel.setEnabled(true); dialogProgress.setVisibility(View.GONE);
                    Toast.makeText(this, "No se pudo enviar el enlace. Revisa tu conexión e inténtalo otra vez.", Toast.LENGTH_LONG).show();
                }
            });
        });
        dialog.setOnShowListener(v -> { if (current.isEmpty()) dialogEmail.requestFocus(); });
        dialog.show();
        if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
    }

    private void saveSession(String userName, String type) {
        getSharedPreferences("usuario", MODE_PRIVATE).edit().putString("nombre", userName).putString("tipo", type).apply();
    }
    private String text(EditText field) { return field.getText().toString().trim(); }
    private void busy(boolean value) { progress.setVisibility(value ? View.VISIBLE : View.GONE); findViewById(R.id.btnLogin).setEnabled(!value); findViewById(R.id.btnContinuar).setEnabled(!value); }
}
