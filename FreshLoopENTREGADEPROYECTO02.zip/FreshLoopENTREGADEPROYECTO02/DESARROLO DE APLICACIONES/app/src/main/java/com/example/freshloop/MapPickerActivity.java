package com.example.freshloop;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

import java.util.Locale;

public class MapPickerActivity extends AppCompatActivity {
    private WebView webView; private double latitude, longitude;
    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_map_picker);
        latitude=getIntent().getDoubleExtra("latitude",-11.9600);longitude=getIntent().getDoubleExtra("longitude",-77.0670);showCoordinates();
        findViewById(R.id.btnBackPicker).setOnClickListener(v->finish());
        findViewById(R.id.btnConfirmLocation).setOnClickListener(v->{Intent result=new Intent().putExtra("latitude",latitude).putExtra("longitude",longitude);setResult(RESULT_OK,result);finish();});
        webView=findViewById(R.id.webMapPicker);webView.getSettings().setJavaScriptEnabled(true);webView.getSettings().setDomStorageEnabled(true);webView.getSettings().setAllowFileAccess(false);webView.getSettings().setAllowContentAccess(false);webView.getSettings().setUserAgentString(webView.getSettings().getUserAgentString()+" FreshLoop/1.0");
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient(){@Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return loader.shouldInterceptRequest(r.getUrl());}@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !"appassets.androidplatform.net".equals(r.getUrl().getHost());}});
        webView.addJavascriptInterface(new PickerBridge(),"FreshLoopPicker");
        webView.loadUrl("https://appassets.androidplatform.net/assets/map/map_picker.html?lat="+latitude+"&lng="+longitude);
    }
    private void showCoordinates(){((TextView)findViewById(R.id.tvPickedCoordinates)).setText(String.format(Locale.US,"Latitud %.6f · Longitud %.6f",latitude,longitude));}
    private final class PickerBridge{@JavascriptInterface public void onReady(){}@JavascriptInterface public void onPicked(double lat,double lng){if(lat< -90||lat>90||lng< -180||lng>180)return;runOnUiThread(()->{latitude=lat;longitude=lng;showCoordinates();});}}
    @Override protected void onDestroy(){if(webView!=null){webView.removeJavascriptInterface("FreshLoopPicker");webView.destroy();}super.onDestroy();}
}
