package com.example.freshloop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class PublicationsActivity extends AppCompatActivity {
    private final List<DocumentSnapshot> foods = new ArrayList<>();
    private ListView list;
    private TextView empty;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_collection);
        ((TextView) findViewById(R.id.tvCollectionTitle)).setText("Mis publicaciones");
        ((TextView) findViewById(R.id.tvCollectionSubtitle)).setText("Edita y revisa el estado de tus excedentes");
        findViewById(R.id.btnBackCollection).setOnClickListener(v -> finish());
        list = findViewById(R.id.lvCollection);
        empty = findViewById(R.id.tvCollectionEmpty);
        empty.setText("Aún no tienes publicaciones.");
        list.setOnItemClickListener((parent, view, position, id) -> startActivity(new Intent(this, EditFoodActivity.class)
                .putExtra("food_doc_id", foods.get(position).getId())));
        NavigationHelper.setup(this, (BottomNavigationView) findViewById(R.id.bottomNavigation), R.id.nav_publications);
    }

    @Override protected void onResume() { super.onResume(); load(); }

    private void load() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { finish(); return; }
        FirebaseFirestore.getInstance().collection("foods").whereEqualTo("uidNegocio", uid).get()
                .addOnSuccessListener(snapshot -> {
                    foods.clear(); foods.addAll(snapshot.getDocuments());
                    list.setAdapter(new FirestoreFoodAdapter(this, foods, true));
                    empty.setVisibility(foods.isEmpty() ? View.VISIBLE : View.GONE);
                }).addOnFailureListener(e -> Toast.makeText(this, "No se pudieron cargar tus publicaciones", Toast.LENGTH_LONG).show());
    }
}
