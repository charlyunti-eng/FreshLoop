package com.example.freshloop;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashSet;
import java.util.Set;

public class DetailFoodActivity extends AppCompatActivity {
    private DocumentSnapshot food;
    private String id;
    private final Set<String> favoriteIds = new HashSet<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_detail_food);
        id = getIntent().getStringExtra("food_doc_id"); if (id == null) { finish(); return; }
        findViewById(R.id.btnBackDetail).setOnClickListener(v -> finish());
        findViewById(R.id.btnReservar).setOnClickListener(v -> startActivity(new Intent(this, ConfirmReservationActivity.class).putExtra("food_doc_id", id)));
        findViewById(R.id.tvMapaReferencial).setOnClickListener(v -> startActivity(new Intent(this, MapActivity.class).putExtra("business_uid", food == null ? null : food.getString("uidNegocio"))));
        findViewById(R.id.btnViewBusiness).setOnClickListener(v -> { if (food != null) startActivity(new Intent(this, PublicBusinessActivity.class).putExtra("business_uid", food.getString("uidNegocio"))); });
        findViewById(R.id.btnFavoriteDetail).setOnClickListener(v -> toggleFavorite());
    }

    @Override protected void onResume() { super.onResume(); load(); loadFavorite(); }

    private void load() {
        FirebaseFirestore.getInstance().collection("foods").document(id).get().addOnSuccessListener(d -> { food = d; show(); })
                .addOnFailureListener(e -> Toast.makeText(this, "No se pudo cargar el alimento", Toast.LENGTH_LONG).show());
    }

    private void show() {
        if (food == null || !food.exists()) { finish(); return; }
        Number imageVersion = (Number) food.get("imageVersion");
        ImageRepository.load(food.getString("imageId"), imageVersion == null ? 0 : imageVersion.longValue(), (ImageView) findViewById(R.id.ivDetailPhoto));
        set(R.id.tvDetalleNombre, value("name")); set(R.id.tvDetalleDescripcion, "Descripción: " + value("description"));
        set(R.id.tvDetalleCantidad, "Cantidad: " + ReservationRepository.stock(food.get("quantity")));
        set(R.id.tvDetalleCategoria, "Categoría: " + value("category")); set(R.id.tvDetalleFecha, "Vence: " + value("expiration"));
        long price = ReservationRepository.cents(food.getString("price"));
        set(R.id.tvDetallePrecio, price == 0 ? "Precio: Gratis" : "Precio: " + ReservationRepository.money(price));
        set(R.id.tvDetalleTipo, "Modalidad: " + value("type")); set(R.id.tvDetalleDireccion, "Referencia: " + value("address") + " · Zona: " + value("zone"));
        set(R.id.tvDetallePublicador, "Publicado por: " + value("publisher")); set(R.id.tvUbicacionDireccion, "Dirección: " + value("address")); set(R.id.tvUbicacionZona, "Zona/Distrito: " + value("zone"));
        String current = value("status"); TextView status = findViewById(R.id.tvDetalleEstado); status.setText("Estado: " + current);
        boolean available = ReservationRepository.isOfferable(food);
        status.setBackgroundResource(available ? R.drawable.badge_available : R.drawable.badge_reserved);
        status.setTextColor(getColor(available ? R.color.green_dark : R.color.orange_soft));
        Button reserve = findViewById(R.id.btnReservar); reserve.setEnabled(available); reserve.setText(available ? "Elegir cantidad y reservar" : "No disponible para reservar");
    }

    private void loadFavorite() {
        try { FavoriteRepository.getFavorites().addOnSuccessListener(s -> { favoriteIds.clear(); for (DocumentSnapshot d : s.getDocuments()) favoriteIds.add(d.getId()); updateFavoriteButton(); }); }
        catch (IllegalStateException ignored) { }
    }
    private void toggleFavorite() {
        boolean exists = favoriteIds.contains(id);
        (exists ? FavoriteRepository.remove(id) : FavoriteRepository.add(id)).addOnSuccessListener(v -> { if (exists) favoriteIds.remove(id); else favoriteIds.add(id); updateFavoriteButton(); });
    }
    private void updateFavoriteButton() { ((Button) findViewById(R.id.btnFavoriteDetail)).setText(favoriteIds.contains(id) ? "Guardado" : "Guardar"); }
    private void set(int viewId, String text) { ((TextView) findViewById(viewId)).setText(text); }
    private String value(String field) { String value = food.getString(field); return value == null || value.trim().isEmpty() ? "No especificado" : value; }
}
