package com.example.freshloop;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

public class ReservationSuccessActivity extends AppCompatActivity {
    private String code = "";
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_reservation_success);
        String id = getIntent().getStringExtra("reservation_id"); if (id == null) { finish(); return; }
        findViewById(R.id.btnSuccessReservations).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)));
        findViewById(R.id.btnSuccessExplore).setOnClickListener(v -> startActivity(new Intent(this, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))); 
        findViewById(R.id.btnCopyCode).setOnClickListener(v -> {
            copyCode(this, code);
            Toast.makeText(this, "Código copiado", Toast.LENGTH_SHORT).show();
        });
        FirebaseFirestore.getInstance().collection("reservations").document(id).get().addOnSuccessListener(r -> {
            code = safe(r.getString("codigo"), id.substring(0, Math.min(8, id.length())).toUpperCase());
            set(R.id.tvSuccessCode, code); set(R.id.tvSuccessFood, safe(r.getString("nombreAlimento"), "Alimento reservado")); set(R.id.tvSuccessBusiness, safe(r.getString("nombreNegocio"), "Negocio FreshLoop"));
            set(R.id.tvSuccessAddress, safe(r.getString("direccion"), "Sin dirección") + " · " + safe(r.getString("zona"), "Sin zona"));
            Number quantity = (Number) r.get("quantityReserved"); Number total = (Number) r.get("totalCents");
            set(R.id.tvSuccessSummary, "Cantidad: " + (quantity == null ? 1 : quantity.intValue()) + "\nTotal acordado: " + (total == null || total.longValue() == 0 ? "Gratis" : ReservationRepository.money(total.longValue())) + "\nEstado: " + safe(r.getString("estadoReserva"), "Confirmada"));
        });
    }
    public static void copyCode(android.content.Context context, String value) {
        ((ClipboardManager) context.getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Código FreshLoop", value));
    }
    private void set(int id, String value) { ((TextView) findViewById(id)).setText(value); }
    private String safe(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value; }
}
