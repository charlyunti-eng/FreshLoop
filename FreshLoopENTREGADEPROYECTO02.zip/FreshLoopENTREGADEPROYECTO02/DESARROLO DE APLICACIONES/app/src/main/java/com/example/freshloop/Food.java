package com.example.freshloop;

public class Food {
    private long id;
    private final String nombre, descripcion, cantidad, fechaVencimiento, precio, tipo, direccion, publicador;
    private final String precioOriginal, horaLimite;
    private String estado;

    public Food(long id, String nombre, String descripcion, String cantidad, String fechaVencimiento,
                String precio, String tipo, String direccion, String publicador, String estado) {
        this(id,nombre,descripcion,cantidad,fechaVencimiento,precio,tipo,direccion,publicador,estado,"","");
    }
    public Food(long id, String nombre, String descripcion, String cantidad, String fechaVencimiento,
                String precio, String tipo, String direccion, String publicador, String estado,
                String precioOriginal, String horaLimite) {
        this.id = id; this.nombre = nombre; this.descripcion = descripcion; this.cantidad = cantidad;
        this.fechaVencimiento = fechaVencimiento; this.precio = precio; this.tipo = tipo;
        this.direccion = direccion; this.publicador = publicador; this.estado = estado;
        this.precioOriginal=precioOriginal;this.horaLimite=horaLimite;
    }
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public String getCantidad() { return cantidad; }
    public String getFechaVencimiento() { return fechaVencimiento; }
    public String getPrecio() { return precio; }
    public String getTipo() { return tipo; }
    public String getDireccion() { return direccion; }
    public String getPublicador() { return publicador; }
    public String getEstado() { return estado; }
    public String getPrecioOriginal(){return precioOriginal;}
    public String getHoraLimite(){return horaLimite;}
    public void setEstado(String estado) { this.estado = estado; }
}
