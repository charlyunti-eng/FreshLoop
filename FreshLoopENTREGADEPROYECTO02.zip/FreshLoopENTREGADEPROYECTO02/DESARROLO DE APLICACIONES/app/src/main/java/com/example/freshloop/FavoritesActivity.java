package com.example.freshloop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FavoritesActivity extends AppCompatActivity {
    private final List<DocumentSnapshot> foods = new ArrayList<>();
    private final Set<String> favoriteIds = new HashSet<>();
    private ListView list;
    private TextView empty;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_collection);
        ((TextView) findViewById(R.id.tvCollectionTitle)).setText("Favoritos");
        ((TextView) findViewById(R.id.tvCollectionSubtitle)).setText("Tus alimentos guardados");
        findViewById(R.id.btnBackCollection).setOnClickListener(v -> finish());
        list = findViewById(R.id.lvCollection);
        empty = findViewById(R.id.tvCollectionEmpty);
        empty.setText("Todavía no guardaste alimentos. Usa el corazón del catálogo.");
        list.setOnItemClickListener((parent, view, position, id) -> startActivity(new Intent(this, DetailFoodActivity.class)
                .putExtra("food_doc_id", foods.get(position).getId())));
        NavigationHelper.setup(this, (BottomNavigationView) findViewById(R.id.bottomNavigation), R.id.nav_favorites);
    }

    @Override protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        FavoriteRepository.getFavorites().addOnSuccessListener(snapshot -> {
            favoriteIds.clear();
            for (DocumentSnapshot favorite : snapshot.getDocuments()) favoriteIds.add(favorite.getId());
            if (favoriteIds.isEmpty()) { show(); return; }
            FirebaseFirestore.getInstance().collection("foods").get().addOnSuccessListener(foodSnapshot -> {
                foods.clear();
                for (DocumentSnapshot food : foodSnapshot.getDocuments())
                    if (favoriteIds.contains(food.getId()) && ReservationRepository.isOfferable(food)) foods.add(food);
                show();
            }).addOnFailureListener(e -> Toast.makeText(this, "No se pudieron cargar los alimentos", Toast.LENGTH_LONG).show());
        }).addOnFailureListener(e -> Toast.makeText(this, "No se pudieron cargar tus favoritos", Toast.LENGTH_LONG).show());
    }

    private void show() {
        list.setAdapter(new FirestoreFoodAdapter(this, foods, false, favoriteIds, this::toggleFavorite,
                food -> startActivity(new Intent(this, DetailFoodActivity.class).putExtra("food_doc_id", food.getId()))));
        empty.setVisibility(foods.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void toggleFavorite(DocumentSnapshot food) {
        FavoriteRepository.remove(food.getId()).addOnSuccessListener(v -> load());
    }
}
