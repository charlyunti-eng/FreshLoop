package com.example.freshloop;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class AccountActivity extends AppCompatActivity {
    private static final String TAG = "FreshLoopImage";
    private String role;
    private String uid;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_account);
        role = getSharedPreferences("usuario", MODE_PRIVATE).getString("tipo", "Cliente");
        uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { finish(); return; }
        ((TextView) findViewById(R.id.tvAccountName)).setText(getSharedPreferences("usuario", MODE_PRIVATE).getString("nombre", "Usuario"));
        ((TextView) findViewById(R.id.tvAccountRole)).setText("Cuenta " + role);
        if (FirebaseAuth.getInstance().getCurrentUser() != null) ((TextView) findViewById(R.id.tvAccountEmail)).setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
        boolean business = "Negocio".equals(role);
        findViewById(R.id.panelAccountMetrics).setVisibility(business ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnAccountPublications).setVisibility(business ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnAccountStats).setVisibility(business ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnAccountEdit).setOnClickListener(v -> startActivity(new Intent(this, business ? BusinessActivity.class : EditProfileActivity.class)));
        findViewById(R.id.btnAccountPhoto).setOnClickListener(v -> startActivity(new Intent(this, business ? BusinessActivity.class : EditProfileActivity.class).putExtra("pick_photo", true)));
        findViewById(R.id.btnAccountPublications).setOnClickListener(v -> startActivity(new Intent(this, PublicationsActivity.class)));
        findViewById(R.id.btnAccountReservations).setOnClickListener(v -> startActivity(new Intent(this, business ? ReservationsActivity.class : HistoryActivity.class)));
        findViewById(R.id.btnAccountStats).setOnClickListener(v -> startActivity(new Intent(this, StatisticsActivity.class)));
        findViewById(R.id.btnAccountNotifications).setOnClickListener(v -> startActivity(new Intent(this, NotificationsActivity.class)));
        findViewById(R.id.btnAccountSettings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.btnAccountLogout).setOnClickListener(v -> confirmLogout());
        NavigationHelper.setup(this, (BottomNavigationView) findViewById(R.id.bottomNavigation), R.id.nav_account);
        loadMetrics();
    }

    @Override protected void onResume() { super.onResume(); loadIdentity(); }

    private void loadIdentity() {
        String authUid = FirebaseAuth.getInstance().getCurrentUser() == null ? null : FirebaseAuth.getInstance().getCurrentUser().getUid();
        Log.i(TAG, "AccountActivity loadIdentity uid=" + authUid);
        if (authUid == null) return;
        FirebaseRepository.getUser(uid).addOnSuccessListener(user -> {
            Log.i(TAG, "users document uid=" + uid + " exists=" + user.exists());
            if (!user.exists()) return;
            String name = user.getString("nombre");
            if (name != null) {
                ((TextView) findViewById(R.id.tvAccountName)).setText(name);
                getSharedPreferences("usuario", MODE_PRIVATE).edit().putString("nombre", name).apply();
            }
            if (!"Negocio".equals(role)) {
                Number version=(Number)user.get("imageVersion");
                String imageId=user.getString("imageId");
                Log.i(TAG, "users imageId=" + imageId + " imageVersion=" + (version == null ? 0 : version.longValue()));
                ImageRepository.load(imageId,version==null?0:version.longValue(),(ImageView)findViewById(R.id.ivAccountPhoto));
            }
        });
        if ("Negocio".equals(role)) FirebaseFirestore.getInstance().collection("businesses").document(uid).get().addOnSuccessListener(business -> {
            String businessName = business.getString("nombreNegocio");
            if (businessName != null && !businessName.trim().isEmpty()) ((TextView) findViewById(R.id.tvAccountName)).setText(businessName);
            Number version=(Number)business.get("imageVersion");ImageRepository.load(business.getString("imageId"),version==null?0:version.longValue(),(ImageView)findViewById(R.id.ivAccountPhoto));
        });
    }

    private void loadMetrics() {
        if (!"Negocio".equals(role)) return;
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("foods").whereEqualTo("uidNegocio", uid).get().addOnSuccessListener(s -> ((TextView) findViewById(R.id.tvAccountPublications)).setText(String.valueOf(s.size())));
        db.collection("reservations").whereEqualTo("uidNegocio", uid).get().addOnSuccessListener(s -> {
            int completed = 0;
            for (com.google.firebase.firestore.DocumentSnapshot d : s.getDocuments()) if ("Completada".equals(d.getString("estadoReserva"))) completed++;
            ((TextView) findViewById(R.id.tvAccountReservations)).setText(String.valueOf(s.size()));
            ((TextView) findViewById(R.id.tvAccountCompleted)).setText(String.valueOf(completed));
        });
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this).setTitle("Cerrar sesión").setMessage("¿Deseas salir de FreshLoop?")
                .setNegativeButton("Cancelar", null).setPositiveButton("Cerrar sesión", (d, w) -> {
                    FirebaseAuth.getInstance().signOut();
                    getSharedPreferences("usuario", MODE_PRIVATE).edit().clear().apply();
                    Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent); finish();
                }).show();
    }
}
