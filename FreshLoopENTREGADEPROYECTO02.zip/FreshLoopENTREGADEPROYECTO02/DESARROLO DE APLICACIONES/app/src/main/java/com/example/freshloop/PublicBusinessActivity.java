package com.example.freshloop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class PublicBusinessActivity extends AppCompatActivity {
    private final List<DocumentSnapshot> foods = new ArrayList<>();
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_public_business);
        findViewById(R.id.btnBackPublicBusiness).setOnClickListener(v -> finish());
        String uid = getIntent().getStringExtra("business_uid"); if (uid == null) { finish(); return; }
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("businesses").document(uid).get().addOnSuccessListener(b -> {
            ((TextView) findViewById(R.id.tvPublicBusinessName)).setText(safe(b.getString("nombreNegocio"), "Negocio FreshLoop"));
            ((TextView) findViewById(R.id.tvPublicBusinessDescription)).setText(safe(b.getString("descripcion"), "Negocio participante de FreshLoop"));
            ((TextView) findViewById(R.id.tvPublicBusinessAddress)).setText(safe(b.getString("direccion"), "Sin dirección") + " · " + safe(b.getString("zona"), "Sin zona"));
            ((TextView) findViewById(R.id.tvPublicBusinessContact)).setText("Teléfono: " + safe(b.getString("telefono"), "No registrado") + " · Horario: " + safe(b.getString("horario"), "No registrado"));
            Number version = (Number) b.get("imageVersion");
            ImageRepository.load(b.getString("imageId"), version == null ? 0 : version.longValue(), (ImageView) findViewById(R.id.ivPublicBusinessPhoto));
            Button map = findViewById(R.id.btnPublicBusinessMap);
            boolean confirmed = b.getGeoPoint("location") != null && Boolean.TRUE.equals(b.getBoolean("locationConfirmed"));
            map.setEnabled(confirmed); map.setText(confirmed ? "Ver punto confirmado" : "Sin ubicación confirmada");
            map.setOnClickListener(v -> startActivity(new Intent(this, MapActivity.class).putExtra("business_uid", uid)));
        });
        ListView list = findViewById(R.id.lvPublicBusinessFoods);
        list.setOnItemClickListener((parent, view, position, id) -> startActivity(new Intent(this, DetailFoodActivity.class).putExtra("food_doc_id", foods.get(position).getId())));
        db.collection("foods").whereEqualTo("uidNegocio", uid).get().addOnSuccessListener(s -> {
            foods.clear();
            for (DocumentSnapshot food : s.getDocuments()) if (ReservationRepository.isOfferable(food)) foods.add(food);
            list.setAdapter(new FirestoreFoodAdapter(this, foods, false));
            ((TextView) findViewById(R.id.tvPublicFoodsTitle)).setText("Publicaciones vigentes · " + foods.size());
            findViewById(R.id.tvPublicBusinessEmpty).setVisibility(foods.isEmpty() ? View.VISIBLE : View.GONE);
        }).addOnFailureListener(e -> Toast.makeText(this, "No se pudo cargar el negocio", Toast.LENGTH_LONG).show());
    }
    private String safe(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value; }
}
