package com.example.freshloop;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ReservationsActivity extends AppCompatActivity {
    private final ArrayList<DocumentSnapshot> records = new ArrayList<>();
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_records);
        ((TextView) findViewById(R.id.tvRecordsTitle)).setText("Reservas recibidas");
        ((TextView) findViewById(R.id.tvRecordsSubtitle)).setText("Bandeja de solicitudes de tus clientes");
        ((TextView) findViewById(R.id.tvRecordsEmpty)).setText("Todavía no recibiste reservas para tus alimentos publicados.");
        findViewById(R.id.btnBackRecords).setOnClickListener(v -> finish());
        ((ListView) findViewById(R.id.lvRecords)).setOnItemClickListener((p, v, position, id) -> startActivity(new Intent(this, ReservationDetailActivity.class).putExtra("reservation_id", records.get(position).getId())));
        NavigationHelper.setup(this, (BottomNavigationView) findViewById(R.id.bottomNavigation), R.id.nav_reservations);
    }

    @Override protected void onResume() { super.onResume(); load(); }

    private void load() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { finish(); return; }
        FirebaseFirestore.getInstance().collection("reservations").whereEqualTo("uidNegocio", uid).get()
                .addOnSuccessListener(snapshot -> {
                    records.clear(); records.addAll(snapshot.getDocuments());
                    ((ListView) findViewById(R.id.lvRecords)).setAdapter(new ReservationCardAdapter(this, records, true));
                    findViewById(R.id.tvRecordsEmpty).setVisibility(records.isEmpty() ? View.VISIBLE : View.GONE);
                })
                .addOnFailureListener(error -> Toast.makeText(this, "No se pudieron cargar las reservas", Toast.LENGTH_LONG).show());
    }
}
