package com.example.freshloop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ReservationCardAdapter extends BaseAdapter {
    private final Context context;
    private final List<DocumentSnapshot> reservations;
    private final boolean businessMode;

    public ReservationCardAdapter(Context context, List<DocumentSnapshot> reservations, boolean businessMode) {
        this.context = context;
        this.reservations = reservations;
        this.businessMode = businessMode;
    }

    @Override public int getCount() { return reservations.size(); }
    @Override public String getItem(int position) {
        DocumentSnapshot reservation = reservations.get(position);
        return value(reservation, "nombreAlimento") + " · " + value(reservation, "estadoReserva");
    }
    @Override public long getItemId(int position) { return position; }

    @Override public View getView(int position, View recycled, ViewGroup parent) {
        View view = recycled == null
                ? LayoutInflater.from(context).inflate(R.layout.item_reservation_card, parent, false)
                : recycled;
        DocumentSnapshot reservation = reservations.get(position);
        set(view, R.id.tvReservationFood, value(reservation, "nombreAlimento"));
        set(view, R.id.tvReservationPersonLabel, businessMode ? "Cliente" : "Reserva realizada por");
        set(view, R.id.tvReservationPerson, businessMode ? value(reservation, "nombreCliente") : "Ti");
        Timestamp timestamp = reservation.getTimestamp("fechaReserva");
        String date = timestamp == null ? "Fecha pendiente" : new SimpleDateFormat("dd MMM yyyy · HH:mm", Locale.getDefault()).format(timestamp.toDate());
        set(view, R.id.tvReservationDate, date);
        String address = reservation.getString("direccion");
        String zone = reservation.getString("zona");
        set(view, R.id.tvReservationLocation, address == null && zone == null ? "Ubicación registrada en el alimento" : "Recojo: " + safe(address) + " · " + safe(zone));
        Number quantity = (Number) reservation.get("quantityReserved");
        Number total = (Number) reservation.get("totalCents");
        String code = reservation.getString("codigo");
        set(view, R.id.tvReservationSummary, "Cantidad: " + (quantity == null ? 1 : quantity.intValue()) + " · " +
                (total == null || total.longValue() == 0 ? "Gratis" : ReservationRepository.money(total.longValue())) +
                (code == null ? "" : " · " + code));
        TextView state = view.findViewById(R.id.tvReservationState);
        state.setText(value(reservation, "estadoReserva"));
        state.setBackgroundResource(R.drawable.badge_available);
        return view;
    }

    private void set(View view, int id, String value) { ((TextView) view.findViewById(id)).setText(value); }
    private String value(DocumentSnapshot document, String field) { return safe(document.getString(field)); }
    private String safe(String value) { return value == null || value.trim().isEmpty() ? "No especificado" : value; }
}
