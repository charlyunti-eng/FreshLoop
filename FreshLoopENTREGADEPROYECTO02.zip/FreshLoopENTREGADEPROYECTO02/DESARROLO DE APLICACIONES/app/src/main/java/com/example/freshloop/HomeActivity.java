package com.example.freshloop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Comparator;
import java.text.Normalizer;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class HomeActivity extends AppCompatActivity {
    private final ArrayList<DocumentSnapshot> docs = new ArrayList<>();
    private final ArrayList<DocumentSnapshot> allDocs = new ArrayList<>();
    private ListView foodList;
    private final Set<String> favoriteIds = new HashSet<>();
    private String role;
    private String sessionUid;
    private String selectedCategory = "Todos";
    private String searchQuery = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_home);
        foodList = findViewById(R.id.lvAlimentos);

        String name = getSharedPreferences("usuario", MODE_PRIVATE).getString("nombre", "Usuario");
        role = getSharedPreferences("usuario", MODE_PRIVATE).getString("tipo", "Cliente");
        sessionUid = FirebaseAuth.getInstance().getUid();
        ((TextView) findViewById(R.id.tvSaludo)).setText("Hola, " + name);
        ((TextView) findViewById(R.id.tvHomeSubtitle)).setText("Negocio".equals(role)
                ? "Panel de gestión de alimentos y reservas"
                : "Descubre alimentos disponibles cerca de ti");
        ((TextView) findViewById(R.id.tvHomeSectionTitle)).setText("Negocio".equals(role)
                ? "Mis alimentos publicados" : "Catálogo de alimentos");

        findViewById(R.id.btnPublicar).setOnClickListener(v -> startActivity(new Intent(this, AddFoodActivity.class)));
        findViewById(R.id.btnNegocio).setOnClickListener(v -> startActivity(new Intent(this, BusinessActivity.class)));
        findViewById(R.id.btnHistorial).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.btnRecibidas).setOnClickListener(v -> startActivity(new Intent(this, ReservationsActivity.class)));
        findViewById(R.id.btnCerrarSesion).setOnClickListener(v -> logout());
        findViewById(R.id.btnNotifications).setOnClickListener(v -> startActivity(new Intent(this, NotificationsActivity.class)));
        findViewById(R.id.btnAccountAvatar).setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        findViewById(R.id.btnExploreMap).setOnClickListener(v -> startActivity(new Intent(this, MapActivity.class)));

        EditText search = findViewById(R.id.etSearchFoods);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = normalize(s == null ? "" : s.toString());
                applyFilter();
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        Spinner filter = findViewById(R.id.spFiltroCategoria);
        filter.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Todos", "Panadería", "Restaurantes", "Postres", "Comida preparada", "Otros", "Donaciones", "Ofertas"}));
        filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                selectedCategory = parent.getItemAtPosition(position).toString();
                applyFilter();
            }
        });

        boolean business = "Negocio".equals(role);
        findViewById(R.id.btnPublicar).setVisibility(business ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnNegocio).setVisibility(business ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnRecibidas).setVisibility(business ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnHistorial).setVisibility(business ? View.GONE : View.VISIBLE);
        findViewById(R.id.panelBusinessStats).setVisibility(business ? View.VISIBLE : View.GONE);
        findViewById(R.id.panelClientFilter).setVisibility(business ? View.GONE : View.VISIBLE);
        NavigationHelper.setup(this, findViewById(R.id.bottomNavigation), R.id.nav_home);

        foodList.setOnItemClickListener((parent, view, position, id) -> openFood(position));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!hasActiveSession()) return;
        if (!"Negocio".equals(role)) loadFavorites();
        FirebaseFirestore.getInstance().collection("foods").get()
                .addOnSuccessListener(snapshot -> {
                    if (!hasActiveSession()) return;
                    allDocs.clear();
                    allDocs.addAll(snapshot.getDocuments());
                    applyFilter();
                    if ("Negocio".equals(role)) loadBusinessStats();
                })
                .addOnFailureListener(error -> {
                    if (hasActiveSession()) Toast.makeText(this, "No se pudo actualizar el catálogo", Toast.LENGTH_LONG).show();
                });
    }

    private void openFood(int position) {
        if (position < 0 || position >= docs.size()) return;
        openFoodDocument(docs.get(position));
    }

    private void openFoodDocument(DocumentSnapshot selected) {
        String uid = FirebaseAuth.getInstance().getUid();
        Class<?> destination = "Negocio".equals(role) && uid != null && uid.equals(selected.getString("uidNegocio"))
                ? EditFoodActivity.class : DetailFoodActivity.class;
        Intent intent = new Intent(this, destination).putExtra("food_doc_id", selected.getId());
        if (destination == EditFoodActivity.class) {
            intent.putExtra("food_name", selected.getString("name"));
            intent.putExtra("food_description", selected.getString("description"));
            intent.putExtra("food_quantity", String.valueOf(selected.get("quantity")));
            intent.putExtra("food_category", selected.getString("category"));
            intent.putExtra("food_expiration", selected.getString("expiration"));
            intent.putExtra("food_type", selected.getString("type"));
            intent.putExtra("food_price", selected.getString("price"));
            intent.putExtra("food_original_price", selected.getString("originalPrice"));
            intent.putExtra("food_pickup_time", selected.getString("pickupTime"));
            intent.putExtra("food_address", selected.getString("address"));
            intent.putExtra("food_zone", selected.getString("zone"));
        }
        startActivity(intent);
    }

    private void applyFilter() {
        docs.clear();
        String uid = FirebaseAuth.getInstance().getUid();
        for (DocumentSnapshot food : allDocs) {
            boolean visibleForRole = !"Negocio".equals(role) || (uid != null && uid.equals(food.getString("uidNegocio")));
            if (!"Negocio".equals(role) && !ReservationRepository.isOfferable(food)) continue;
            String category = value(food, "category");
            String type = value(food, "type");
            boolean visibleForCategory;
            if ("Todos".equals(selectedCategory)) visibleForCategory = true;
            else if ("Donaciones".equals(selectedCategory)) visibleForCategory = normalize(type).contains("donacion");
            else if ("Ofertas".equals(selectedCategory)) visibleForCategory = !normalize(type).contains("donacion");
            else visibleForCategory = normalize(selectedCategory).equals(normalize(category));
            String searchable = normalize(value(food, "name") + " " + value(food, "publisher") + " " + category);
            boolean visibleForSearch = searchQuery.isEmpty() || searchable.contains(searchQuery);
            if (visibleForRole && visibleForCategory && visibleForSearch) docs.add(food);
        }
        docs.sort(Comparator
                .comparingInt((DocumentSnapshot food) -> "Disponible".equals(food.getString("status")) ? 0 : 1)
                .thenComparingInt(food -> food.getString("imageId") == null ? 1 : 0)
                .thenComparing(food -> value(food, "name"), String.CASE_INSENSITIVE_ORDER));
        foodList.setAdapter(new FirestoreFoodAdapter(this, docs, "Negocio".equals(role), favoriteIds,
                this::toggleFavorite, this::openFoodDocument));
        findViewById(R.id.tvHomeEmpty).setVisibility(docs.isEmpty() ? View.VISIBLE : View.GONE);
        ((TextView) findViewById(R.id.tvResultCount)).setText(docs.size() + (docs.size() == 1 ? " resultado" : " resultados"));
        if ("Negocio".equals(role)) updateFoodMetrics();
    }

    private void loadFavorites() {
        FavoriteRepository.getFavorites().addOnSuccessListener(snapshot -> {
            if (!hasActiveSession()) return;
            favoriteIds.clear();
            for (DocumentSnapshot favorite : snapshot.getDocuments()) favoriteIds.add(favorite.getId());
            applyFilter();
        });
    }

    private void toggleFavorite(DocumentSnapshot food) {
        boolean exists = favoriteIds.contains(food.getId());
        (exists ? FavoriteRepository.remove(food.getId()) : FavoriteRepository.add(food.getId()))
                .addOnSuccessListener(v -> {
                    if (exists) favoriteIds.remove(food.getId()); else favoriteIds.add(food.getId());
                    applyFilter();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "No se pudo actualizar el favorito", Toast.LENGTH_LONG).show());
    }

    private String value(DocumentSnapshot document, String field) {
        String value = document.getString(field);
        return value == null ? "" : value;
    }

    private String normalize(String value) {
        return Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT).trim();
    }

    private void updateFoodMetrics() {
        int available = 0;
        int reserved = 0;
        for (DocumentSnapshot food : docs) {
            if ("Reservado".equals(food.getString("status"))) reserved++; else available++;
        }
        ((TextView) findViewById(R.id.tvStatPublished)).setText(String.valueOf(docs.size()));
        ((TextView) findViewById(R.id.tvStatAvailable)).setText(String.valueOf(available));
        ((TextView) findViewById(R.id.tvStatReserved)).setText(String.valueOf(reserved));
    }

    private void loadBusinessStats() {
        if (!hasActiveSession()) return;
        String uid = sessionUid;
        FirebaseFirestore.getInstance().collection("reservations").whereEqualTo("uidNegocio", uid).get()
                .addOnSuccessListener(snapshot -> {
                    if (hasActiveSession()) ((TextView) findViewById(R.id.tvStatReservations)).setText(String.valueOf(snapshot.size()));
                });
    }

    private boolean hasActiveSession() {
        String currentUid = FirebaseAuth.getInstance().getUid();
        return !isFinishing() && !isDestroyed() && sessionUid != null && sessionUid.equals(currentUid);
    }

    private void logout() {
        FirebaseAuth.getInstance().signOut();
        getSharedPreferences("usuario", MODE_PRIVATE).edit().clear().apply();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
