package com.example.freshloop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.List;
import java.util.Collections;
import java.util.Set;

public class FirestoreFoodAdapter extends BaseAdapter {
    private final Context context;
    private final List<DocumentSnapshot> foods;
    private final boolean businessMode;
    private final Set<String> favoriteIds;
    private final FavoriteAction favoriteAction;
    private final FoodAction foodAction;

    public interface FavoriteAction { void onFavorite(DocumentSnapshot food); }
    public interface FoodAction { void onOpen(DocumentSnapshot food); }

    public FirestoreFoodAdapter(Context context, List<DocumentSnapshot> foods, boolean businessMode) {
        this(context, foods, businessMode, Collections.emptySet(), null, null);
    }

    public FirestoreFoodAdapter(Context context, List<DocumentSnapshot> foods, boolean businessMode,
                                Set<String> favoriteIds, FavoriteAction favoriteAction) {
        this(context, foods, businessMode, favoriteIds, favoriteAction, null);
    }

    public FirestoreFoodAdapter(Context context, List<DocumentSnapshot> foods, boolean businessMode,
                                Set<String> favoriteIds, FavoriteAction favoriteAction, FoodAction foodAction) {
        this.context = context;
        this.foods = foods;
        this.businessMode = businessMode;
        this.favoriteIds = favoriteIds;
        this.favoriteAction = favoriteAction;
        this.foodAction = foodAction;
    }

    @Override public int getCount() { return foods.size(); }

    @Override public String getItem(int position) {
        DocumentSnapshot food = foods.get(position);
        return value(food, "name") + " · " + value(food, "status") + " · " + value(food, "category");
    }

    @Override public long getItemId(int position) { return position; }

    @Override public View getView(int position, View recycled, ViewGroup parent) {
        View view = recycled == null
                ? LayoutInflater.from(context).inflate(R.layout.item_food_card, parent, false)
                : recycled;
        DocumentSnapshot food = foods.get(position);
        Number imageVersion = (Number) food.get("imageVersion");
        ImageRepository.load(food.getString("imageId"), imageVersion == null ? 0 : imageVersion.longValue(),
                (ImageView) view.findViewById(R.id.ivItemPhoto));
        set(view, R.id.tvItemNombre, value(food, "name"));
        set(view, R.id.tvItemCategory, value(food, "category"));
        set(view, R.id.tvItemPublisher, value(food, "publisher"));
        set(view, R.id.tvItemCantidad, "Cantidad disponible: " + objectValue(food, "quantity"));
        String type = value(food, "type");
        String price = value(food, "price");
        set(view, R.id.tvItemPrecio, "Donación".equals(type) ? "Donación gratuita" : "S/ " + price);
        set(view, R.id.tvItemZona, "Zona: " + value(food, "zone"));
        TextView status = view.findViewById(R.id.tvItemEstado);
        String state = value(food, "status");
        status.setText(state);
        status.setTextColor(context.getColor("Reservado".equals(state) ? R.color.orange_soft : R.color.green_dark));
        status.setBackgroundResource("Reservado".equals(state) ? R.drawable.badge_reserved : R.drawable.badge_available);
        TextView action = view.findViewById(R.id.btnItemAction);
        action.setText(businessMode ? "Editar alimento  ›" : "Ver detalle  ›");
        action.setOnClickListener(foodAction == null ? null : v -> foodAction.onOpen(food));
        ImageButton favorite = view.findViewById(R.id.btnFavorite);
        favorite.setVisibility(businessMode ? View.GONE : View.VISIBLE);
        favorite.setAlpha(favoriteIds.contains(food.getId()) ? 1f : 0.35f);
        favorite.setOnClickListener(favoriteAction == null ? null : v -> favoriteAction.onFavorite(food));
        view.setOnClickListener(foodAction == null ? null : v -> foodAction.onOpen(food));
        return view;
    }

    private void set(View view, int id, String value) { ((TextView) view.findViewById(id)).setText(value); }
    private String value(DocumentSnapshot document, String field) {
        String value = document.getString(field);
        return value == null || value.trim().isEmpty() ? "No especificado" : value;
    }
    private String objectValue(DocumentSnapshot document, String field) {
        Object value = document.get(field);
        return value == null || String.valueOf(value).trim().isEmpty() ? "No especificado" : String.valueOf(value);
    }
}
