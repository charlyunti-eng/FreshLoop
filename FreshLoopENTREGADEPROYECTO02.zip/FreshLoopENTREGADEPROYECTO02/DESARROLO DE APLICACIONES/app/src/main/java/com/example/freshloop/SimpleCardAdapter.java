package com.example.freshloop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class SimpleCardAdapter extends BaseAdapter {
    public static final class Item {
        public final String title;
        public final String body;
        public Item(String title, String body) { this.title = title; this.body = body; }
        @Override public String toString() { return title + " " + body; }
    }
    private final Context context;
    private final List<Item> items;
    public SimpleCardAdapter(Context context, List<Item> items) { this.context = context; this.items = items; }
    @Override public int getCount() { return items.size(); }
    @Override public Item getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return position; }
    @Override public View getView(int position, View recycled, ViewGroup parent) {
        View view = recycled == null ? LayoutInflater.from(context).inflate(R.layout.item_simple_card, parent, false) : recycled;
        Item item = getItem(position);
        ((TextView) view.findViewById(R.id.tvSimpleCardTitle)).setText(item.title);
        ((TextView) view.findViewById(R.id.tvSimpleCardBody)).setText(item.body);
        return view;
    }
}
