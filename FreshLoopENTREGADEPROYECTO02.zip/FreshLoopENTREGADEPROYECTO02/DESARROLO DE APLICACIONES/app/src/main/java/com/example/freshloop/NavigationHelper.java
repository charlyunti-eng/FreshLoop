package com.example.freshloop;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;

import com.google.android.material.bottomnavigation.BottomNavigationView;

/** Configura una navegación principal coherente por rol y evita apilar el mismo destino. */
public final class NavigationHelper {
    private NavigationHelper() { }

    public static void setup(Activity activity, BottomNavigationView navigation, int selectedId) {
        String role = activity.getSharedPreferences("usuario", Activity.MODE_PRIVATE)
                .getString("tipo", "Cliente");
        boolean business = "Negocio".equals(role);
        navigation.setItemActiveIndicatorColor(ColorStateList.valueOf(activity.getColor(R.color.green_light)));
        navigation.getMenu().clear();
        navigation.inflateMenu(business ? R.menu.menu_business_bottom : R.menu.menu_client_bottom);
        navigation.setSelectedItemId(selectedId);
        navigation.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == selectedId) return true;
            Class<?> target;
            if (id == R.id.nav_home) target = HomeActivity.class;
            else if (id == R.id.nav_map) target = MapActivity.class;
            else if (id == R.id.nav_reservations) target = business ? ReservationsActivity.class : HistoryActivity.class;
            else if (id == R.id.nav_favorites) target = FavoritesActivity.class;
            else if (id == R.id.nav_account) target = AccountActivity.class;
            else if (id == R.id.nav_publications) target = PublicationsActivity.class;
            else if (id == R.id.nav_publish) target = AddFoodActivity.class;
            else return false;
            Intent intent = new Intent(activity, target)
                    .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            activity.startActivity(intent);
            return true;
        });
    }
}
