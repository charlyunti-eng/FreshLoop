package com.example.freshloop;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.Log;
import android.widget.ImageView;

import androidx.exifinterface.media.ExifInterface;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.Blob;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.WriteBatch;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Procesa y sincroniza miniaturas JPEG de hasta 100 KiB usando Blob de Firestore. */
public final class ImageRepository {
    private static final String TAG = "FreshLoopImage";
    public static final int MAX_BYTES = 100 * 1024;
    private static final int MAX_DIMENSION = 768;
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final LruCache<String, Bitmap> MEMORY = new LruCache<String, Bitmap>(8 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount() / 1024; }
    };

    public interface Callback { void onSuccess(ProcessedImage image); void onError(Exception error); }

    public static final class ProcessedImage {
        public final byte[] bytes;
        public final int width;
        public final int height;
        ProcessedImage(byte[] bytes, int width, int height) { this.bytes = bytes; this.width = width; this.height = height; }
    }

    private ImageRepository() { }

    public static void process(Context context, Uri uri, Callback callback) {
        EXECUTOR.execute(() -> {
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
                try (InputStream in = context.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, bounds); }
                if (bounds.outWidth < 1 || bounds.outHeight < 1) throw new IllegalArgumentException("La imagen no es válida");
                int sample = 1;
                while (bounds.outWidth / sample > MAX_DIMENSION * 2 || bounds.outHeight / sample > MAX_DIMENSION * 2) sample *= 2;
                BitmapFactory.Options options = new BitmapFactory.Options(); options.inSampleSize = sample;
                Bitmap bitmap;
                try (InputStream in = context.getContentResolver().openInputStream(uri)) { bitmap = BitmapFactory.decodeStream(in, null, options); }
                if (bitmap == null) throw new IllegalArgumentException("No se pudo leer la imagen");
                int orientation = ExifInterface.ORIENTATION_NORMAL;
                try (InputStream in = context.getContentResolver().openInputStream(uri)) { if (in != null) orientation = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL); }
                bitmap = rotate(bitmap, orientation);
                bitmap = scale(bitmap, MAX_DIMENSION);
                byte[] bytes = compress(bitmap);
                if (bytes.length > MAX_BYTES) throw new IllegalArgumentException("No se pudo reducir la imagen por debajo de 100 KiB");
                ProcessedImage result = new ProcessedImage(bytes, bitmap.getWidth(), bitmap.getHeight());
                MAIN.post(() -> callback.onSuccess(result));
            } catch (Exception error) { MAIN.post(() -> callback.onError(error)); }
        });
    }

    public static Task<Void> upload(String entityType, String entityId, ProcessedImage image, DocumentReference entityRef) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) throw new IllegalStateException("Sesión requerida");
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String imageId = entityType + "_" + entityId;
        long version = System.currentTimeMillis();
        DocumentReference imageRef = db.collection("images").document(imageId);
        WriteBatch batch = db.batch();
        batch.set(imageRef, imageData(uid, entityType, entityId, image, version), SetOptions.merge());
        Map<String, Object> link = new HashMap<>(); link.put("imageId", imageId); link.put("imageVersion", version);
        batch.update(entityRef, link);
        return batch.commit();
    }

    public static Task<Void> updateWithImage(String entityType, String entityId, ProcessedImage image,
                                             DocumentReference entityRef, Map<String, Object> entityUpdates) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) throw new IllegalStateException("Sesión requerida");
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String imageId = entityType + "_" + entityId; long version = System.currentTimeMillis();
        entityUpdates.put("imageId", imageId); entityUpdates.put("imageVersion", version);
        WriteBatch batch = db.batch();
        batch.update(entityRef, entityUpdates);
        batch.set(db.collection("images").document(imageId), imageData(uid, entityType, entityId, image, version), SetOptions.merge());
        return batch.commit();
    }

    public static Task<Void> setWithImage(String entityType, String entityId, ProcessedImage image,
                                          DocumentReference entityRef, Map<String, Object> entityData) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) throw new IllegalStateException("Sesión requerida");
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String imageId = entityType + "_" + entityId; long version = System.currentTimeMillis();
        entityData.put("imageId", imageId); entityData.put("imageVersion", version);
        WriteBatch batch = db.batch();
        batch.set(entityRef, entityData, SetOptions.merge());
        batch.set(db.collection("images").document(imageId), imageData(uid, entityType, entityId, image, version), SetOptions.merge());
        return batch.commit();
    }

    public static Map<String, Object> imageData(String uid, String entityType, String entityId, ProcessedImage image, long version) {
        Map<String, Object> data = new HashMap<>();
        data.put("ownerUid", uid); data.put("entityType", entityType); data.put("entityId", entityId);
        data.put("mime", "image/jpeg"); data.put("width", image.width); data.put("height", image.height);
        data.put("version", version); data.put("updatedAt", FieldValue.serverTimestamp()); data.put("content", Blob.fromBytes(image.bytes));
        return data;
    }

    public static void load(String imageId, long version, ImageView target) {
        if (imageId == null || imageId.trim().isEmpty()) {
            Log.i(TAG, "load skipped imageIdMissing");
            target.setImageResource(R.drawable.food_placeholder);
            return;
        }
        String key = imageId + ":" + version; target.setTag(key);
        Log.i(TAG, "load imageId=" + imageId + " version=" + version);
        Bitmap cached = MEMORY.get(key);
        if (cached != null) {
            Log.i(TAG, "cache hit imageId=" + imageId + " bytes=memory");
            target.post(() -> {
                target.setImageTintList(null);
                target.setBackground(null);
                target.setImageResource(0);
                target.setScaleType(ImageView.ScaleType.CENTER_CROP);
                target.setImageBitmap(cached);
            });
            return;
        }
        target.setImageResource(R.drawable.food_placeholder);
        FirebaseFirestore.getInstance().collection("images").document(imageId).get().addOnSuccessListener(document -> {
            Blob blob = document.getBlob("content");
            Log.i(TAG, "document imageId=" + imageId + " exists=" + document.exists() + " bytes=" + (blob == null ? 0 : blob.toBytes().length));
            if (blob == null) { Log.w(TAG, "content blob missing imageId=" + imageId); return; }
            EXECUTOR.execute(() -> {
                byte[] bytes = blob.toBytes();
                Log.i(TAG, "blob sha256 imageId=" + imageId + " sha256=" + sha256(bytes));
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                Log.i(TAG, "decoded imageId=" + imageId + " bitmap=" + (bitmap != null) + " width=" + (bitmap == null ? 0 : bitmap.getWidth()) + " height=" + (bitmap == null ? 0 : bitmap.getHeight()));
                if (bitmap != null) {
                    MEMORY.put(key, bitmap);
                    MAIN.post(() -> {
                        if (key.equals(target.getTag())) {
                            target.setImageTintList(null);
                            target.setBackground(null);
                            target.setImageResource(0);
                            target.setScaleType(ImageView.ScaleType.CENTER_CROP);
                            target.setImageBitmap(bitmap);
                            target.invalidate();
                            Log.i(TAG, "setImageBitmap executed imageId=" + imageId + " tintCleared=true");
                        } else Log.w(TAG, "target tag changed imageId=" + imageId);
                    });
                }
            });
        }).addOnFailureListener(error -> Log.e(TAG, "image read failed imageId=" + imageId + " error=" + error.getClass().getSimpleName() + ":" + error.getMessage()));
    }

    private static String sha256(byte[] bytes) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
            StringBuilder out = new StringBuilder();
            for (byte value : digest) out.append(String.format(java.util.Locale.US, "%02x", value));
            return out.toString();
        } catch (Exception error) {
            return "unavailable:" + error.getClass().getSimpleName();
        }
    }

    private static Bitmap rotate(Bitmap source, int orientation) {
        float degrees = orientation == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : orientation == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : orientation == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
        if (degrees == 0) return source; Matrix matrix = new Matrix(); matrix.postRotate(degrees); return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }
    private static Bitmap scale(Bitmap source, int max) {
        int width = source.getWidth(), height = source.getHeight(); if (width <= max && height <= max) return source;
        float factor = Math.min((float) max / width, (float) max / height); return Bitmap.createScaledBitmap(source, Math.round(width * factor), Math.round(height * factor), true);
    }
    private static byte[] compress(Bitmap bitmap) {
        Bitmap current = bitmap;
        for (int dimensionPass = 0; dimensionPass < 5; dimensionPass++) {
            for (int quality = 86; quality >= 42; quality -= 8) {
                ByteArrayOutputStream out = new ByteArrayOutputStream(); current.compress(Bitmap.CompressFormat.JPEG, quality, out);
                if (out.size() <= MAX_BYTES) return out.toByteArray();
            }
            current = Bitmap.createScaledBitmap(current, Math.max(160, Math.round(current.getWidth() * .82f)), Math.max(160, Math.round(current.getHeight() * .82f)), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream(); current.compress(Bitmap.CompressFormat.JPEG, 38, out); return out.toByteArray();
    }
}
