package com.example.freshloop;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.BitmapFactory;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.SetOptions;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class EditProfileActivity extends AppCompatActivity {
    private EditText name;
    private ProgressBar progress;
    private String uid;
    private ImageRepository.ProcessedImage selectedImage;
    private ActivityResultLauncher<String> imagePicker;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_edit_profile);
        uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { finish(); return; }
        name = findViewById(R.id.etProfileName);
        progress = findViewById(R.id.progressProfile);
        imagePicker = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> { if (uri != null) processImage(uri); });
        findViewById(R.id.btnBackProfile).setOnClickListener(v -> finish());
        findViewById(R.id.btnPickProfilePhoto).setOnClickListener(v -> imagePicker.launch("image/*"));
        findViewById(R.id.btnSaveProfile).setOnClickListener(v -> save());
        if (FirebaseAuth.getInstance().getCurrentUser() != null) ((EditText) findViewById(R.id.etProfileEmail)).setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
        FirebaseRepository.getUser(uid).addOnSuccessListener(d -> { name.setText(d.getString("nombre")); Number version=(Number)d.get("imageVersion");ImageRepository.load(d.getString("imageId"),version==null?0:version.longValue(),(ImageView)findViewById(R.id.ivProfilePhoto));if(getIntent().getBooleanExtra("pick_photo",false)){getIntent().removeExtra("pick_photo");findViewById(R.id.btnPickProfilePhoto).performClick();} });
    }

    private void save() {
        String value = name.getText().toString().trim();
        if (value.isEmpty()) { name.setError("Nombre obligatorio"); return; }
        setBusy(true);
        com.google.firebase.firestore.DocumentReference ref=com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("users").document(uid);
        Map<String,Object> changes=new HashMap<>();changes.put("nombre",value);
        com.google.android.gms.tasks.Task<Void> task=selectedImage==null?ref.set(changes,SetOptions.merge()):ImageRepository.updateWithImage("user",uid,selectedImage,ref,changes);
        task
                .addOnSuccessListener(v -> {
                    getSharedPreferences("usuario", MODE_PRIVATE).edit().putString("nombre", value).apply();
                    Toast.makeText(this, "Perfil actualizado", Toast.LENGTH_SHORT).show(); finish();
                }).addOnFailureListener(e -> { setBusy(false); Toast.makeText(this, "No se pudo actualizar", Toast.LENGTH_LONG).show(); });
    }

    private void processImage(android.net.Uri uri) {
        findViewById(R.id.btnPickProfilePhoto).setEnabled(false);
        ImageRepository.process(this, uri, new ImageRepository.Callback() {
            @Override public void onSuccess(ImageRepository.ProcessedImage image) { selectedImage=image;((ImageView)findViewById(R.id.ivProfilePhoto)).setImageBitmap(BitmapFactory.decodeByteArray(image.bytes,0,image.bytes.length));findViewById(R.id.btnPickProfilePhoto).setEnabled(true);((android.widget.Button)findViewById(R.id.btnPickProfilePhoto)).setText("Foto lista · "+(image.bytes.length/1024)+" KiB"); }
            @Override public void onError(Exception error) { findViewById(R.id.btnPickProfilePhoto).setEnabled(true);Toast.makeText(EditProfileActivity.this,"No se pudo procesar la imagen",Toast.LENGTH_LONG).show(); }
        });
    }

    private void setBusy(boolean busy) { progress.setVisibility(busy ? View.VISIBLE : View.GONE); findViewById(R.id.btnSaveProfile).setEnabled(!busy); }
}
