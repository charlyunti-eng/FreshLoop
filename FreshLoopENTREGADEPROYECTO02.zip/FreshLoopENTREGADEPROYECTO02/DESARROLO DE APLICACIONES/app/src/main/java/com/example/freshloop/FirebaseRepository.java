package com.example.freshloop;

import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.WriteBatch;
import java.util.HashMap;
import java.util.Map;

/** Persistencia Firebase de la aplicación. No usa Admin SDK ni claves privadas. */
public final class FirebaseRepository {
    private FirebaseRepository() { }

    public static Task<Void> saveUser(String uid, String name, String email, String type) {
        Map<String, Object> user = new HashMap<>();
        user.put("uid", uid); user.put("nombre", name); user.put("correo", email); user.put("tipoUsuario", type);
        return FirebaseFirestore.getInstance().collection("users").document(uid).set(user);
    }

    public static Task<DocumentSnapshot> getUser(String uid) {
        return FirebaseFirestore.getInstance().collection("users").document(uid).get();
    }

    public static Task<DocumentReference> saveFood(Food food, String uid, String zone) {
        return saveFood(food, uid, zone, "Sin categoría");
    }
    public static Task<DocumentReference> saveFood(Food food, String uid, String zone, String category) {
        return saveFood(food, uid, zone, category, null);
    }
    public static Task<DocumentReference> saveFood(Food food, String uid, String zone, String category, ImageRepository.ProcessedImage image) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference foodRef = db.collection("foods").document();
        Map<String, Object> data = new HashMap<>();
        data.put("name", food.getNombre()); data.put("description", food.getDescripcion());
        data.put("quantity", ReservationRepository.stock(food.getCantidad())); data.put("expiration", food.getFechaVencimiento());
        data.put("price", food.getPrecio()); data.put("type", food.getTipo()); data.put("category", category);
        data.put("originalPrice", food.getPrecioOriginal()); data.put("pickupTime", food.getHoraLimite());
        data.put("address", food.getDireccion()); data.put("publisher", food.getPublicador());
        data.put("zone", zone); data.put("status", "Disponible"); data.put("published", true);
        data.put("ownerId", uid); data.put("uidNegocio", uid); data.put("fechaCreacion", com.google.firebase.firestore.FieldValue.serverTimestamp());
        WriteBatch batch = db.batch();
        if (image != null) {
            String imageId = "food_" + foodRef.getId(); long version = System.currentTimeMillis();
            data.put("imageId", imageId); data.put("imageVersion", version);
            batch.set(db.collection("images").document(imageId), ImageRepository.imageData(uid, "food", foodRef.getId(), image, version));
        }
        batch.set(foodRef, data);
        return batch.commit().continueWith(task -> { if (!task.isSuccessful()) throw task.getException(); return foodRef; });
    }

    public static FirebaseAuth auth() { return FirebaseAuth.getInstance(); }
}
