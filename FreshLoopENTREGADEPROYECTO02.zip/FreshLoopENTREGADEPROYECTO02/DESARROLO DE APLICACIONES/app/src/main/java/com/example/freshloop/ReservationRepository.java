package com.example.freshloop;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class ReservationRepository {
    private ReservationRepository() { }

    public static Task<DocumentReference> reserve(String foodId, int requestedQuantity, String clientName) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String clientUid = FirebaseAuth.getInstance().getUid();
        if (clientUid == null) throw new IllegalStateException("Sesión requerida");
        DocumentReference foodRef = db.collection("foods").document(foodId);
        DocumentReference userRef = db.collection("users").document(clientUid);
        DocumentReference reservationRef = db.collection("reservations").document();
        DocumentReference guardRef = db.collection("reservationGuards").document(clientUid + "_" + foodId);
        String code = "FL-" + reservationRef.getId().substring(0, 6).toUpperCase(Locale.ROOT);

        return db.runTransaction(transaction -> {
            DocumentSnapshot user = transaction.get(userRef);
            DocumentSnapshot food = transaction.get(foodRef);
            DocumentSnapshot guard = transaction.get(guardRef);
            if (!user.exists() || !"Cliente".equals(user.getString("tipoUsuario"))) throw new IllegalStateException("Solo un Cliente puede reservar");
            if (!food.exists() || !isOfferable(food)) throw new IllegalStateException("Alimento no disponible o publicación vencida");
            if (isExpired(food.getString("expiration"))) throw new IllegalStateException("La publicación está vencida");
            int stock = stock(food.get("quantity"));
            if (requestedQuantity < 1 || requestedQuantity > stock) throw new IllegalStateException("Stock insuficiente");
            if (guard.exists() && Boolean.TRUE.equals(guard.getBoolean("active"))) throw new IllegalStateException("Ya tienes una reserva activa");
            long unitPrice = cents(food.getString("price"));
            long total = unitPrice * requestedQuantity;
            int remaining = stock - requestedQuantity;

            Map<String, Object> foodUpdate = new HashMap<>();
            foodUpdate.put("quantity", remaining);
            foodUpdate.put("status", remaining == 0 ? "Agotado" : "Disponible");
            foodUpdate.put("updatedAt", FieldValue.serverTimestamp());
            foodUpdate.put("lastReservationId", reservationRef.getId());
            transaction.update(foodRef, foodUpdate);

            Map<String, Object> reservation = new HashMap<>();
            reservation.put("foodId", foodId);
            reservation.put("nombreAlimento", food.getString("name"));
            reservation.put("uidCliente", clientUid);
            reservation.put("nombreCliente", clientName);
            reservation.put("uidNegocio", food.getString("uidNegocio"));
            reservation.put("nombreNegocio", food.getString("publisher"));
            reservation.put("estadoReserva", "Confirmada");
            reservation.put("quantityReserved", requestedQuantity);
            reservation.put("unitPriceCents", unitPrice);
            reservation.put("totalCents", total);
            reservation.put("codigo", code);
            reservation.put("direccion", food.getString("address"));
            reservation.put("zona", food.getString("zone"));
            reservation.put("fechaLimite", food.getString("expiration"));
            reservation.put("horaLimite", food.getString("pickupTime"));
            reservation.put("fechaReserva", FieldValue.serverTimestamp());
            transaction.set(reservationRef, reservation);

            Map<String, Object> guardData = new HashMap<>();
            guardData.put("active", true); guardData.put("uidCliente", clientUid); guardData.put("foodId", foodId);
            guardData.put("reservationId", reservationRef.getId()); guardData.put("updatedAt", FieldValue.serverTimestamp());
            transaction.set(guardRef, guardData);
            return null;
        }).continueWith(task -> {
            if (!task.isSuccessful()) throw task.getException();
            return reservationRef;
        });
    }

    public static Task<Void> cancel(String reservationId) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) throw new IllegalStateException("Sesión requerida");
        DocumentReference reservationRef = db.collection("reservations").document(reservationId);
        return db.runTransaction(transaction -> {
            DocumentSnapshot reservation = transaction.get(reservationRef);
            if (!reservation.exists() || !uid.equals(reservation.getString("uidCliente"))) throw new IllegalStateException("No autorizado");
            String status = reservation.getString("estadoReserva");
            if ("Cancelada".equals(status)) return null;
            if (!("Confirmada".equals(status) || "Reservada".equals(status))) throw new IllegalStateException("La reserva ya no se puede cancelar");
            String foodId = reservation.getString("foodId");
            DocumentReference foodRef = db.collection("foods").document(foodId);
            DocumentReference guardRef = db.collection("reservationGuards").document(uid + "_" + foodId);
            DocumentSnapshot food = transaction.get(foodRef);
            DocumentSnapshot guard = transaction.get(guardRef);
            int reserved = number(reservation.get("quantityReserved"), 1);
            Map<String, Object> reservationUpdate = new HashMap<>();
            reservationUpdate.put("estadoReserva", "Cancelada"); reservationUpdate.put("cancelledAt", FieldValue.serverTimestamp());
            transaction.update(reservationRef, reservationUpdate);
            if (food.exists() && !("Retirado".equals(food.getString("status")) || "Vencido".equals(food.getString("status")))) {
                Map<String, Object> foodUpdate = new HashMap<>();
                foodUpdate.put("quantity", stock(food.get("quantity")) + reserved);
                foodUpdate.put("status", "Disponible");
                foodUpdate.put("lastStockMutationReservationId", reservationId);
                foodUpdate.put("updatedAt", FieldValue.serverTimestamp());
                transaction.update(foodRef, foodUpdate);
            }
            if (guard.exists() && reservationId.equals(guard.getString("reservationId"))) transaction.update(guardRef, "active", false, "updatedAt", FieldValue.serverTimestamp());
            return null;
        });
    }

    public static Task<Void> complete(String reservationId) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) throw new IllegalStateException("Sesión requerida");
        DocumentReference reservationRef = db.collection("reservations").document(reservationId);
        return db.runTransaction(transaction -> {
            DocumentSnapshot reservation = transaction.get(reservationRef);
            if (!reservation.exists() || !uid.equals(reservation.getString("uidNegocio"))) throw new IllegalStateException("No autorizado");
            String status = reservation.getString("estadoReserva");
            if ("Completada".equals(status)) return null;
            if (!("Confirmada".equals(status) || "Reservada".equals(status))) throw new IllegalStateException("Transición no permitida");
            String foodId = reservation.getString("foodId");
            String clientUid = reservation.getString("uidCliente");
            DocumentReference guardRef = db.collection("reservationGuards").document(clientUid + "_" + foodId);
            DocumentSnapshot guard = transaction.get(guardRef);
            transaction.update(reservationRef, "estadoReserva", "Completada", "completedAt", FieldValue.serverTimestamp());
            if (guard.exists() && reservationId.equals(guard.getString("reservationId"))) {
                transaction.update(guardRef, "active", false, "updatedAt", FieldValue.serverTimestamp());
            }
            return null;
        });
    }

    public static int stock(Object value) { return number(value, 0); }
    private static int number(Object value, int fallback) {
        if (value instanceof Number) return ((Number) value).intValue();
        try { return (int) Math.floor(Double.parseDouble(String.valueOf(value).replace(',', '.'))); } catch (Exception e) { return fallback; }
    }
    public static long cents(String value) {
        try { return new BigDecimal(value == null ? "0" : value.replace(',', '.')).setScale(2, RoundingMode.HALF_UP).movePointRight(2).longValueExact(); }
        catch (Exception e) { return 0; }
    }
    public static String money(long cents) { return "S/ " + BigDecimal.valueOf(cents, 2).setScale(2, RoundingMode.HALF_UP).toPlainString(); }
    public static boolean isOfferable(DocumentSnapshot food) {
        return food != null && food.exists()
                && Boolean.TRUE.equals(food.getBoolean("published"))
                && "Disponible".equals(food.getString("status"))
                && stock(food.get("quantity")) > 0
                && !isExpired(food.getString("expiration"));
    }
    public static boolean isExpired(String expiration) {
        if (expiration == null || expiration.trim().isEmpty()) return false;
        SimpleDateFormat format = new SimpleDateFormat(expiration.contains("-") ? "dd-MM-yyyy" : "dd/MM/yyyy", Locale.ROOT);
        format.setLenient(false);
        try { Date date = format.parse(expiration); return date != null && date.getTime() + 86_400_000L < System.currentTimeMillis(); }
        catch (ParseException e) { return false; }
    }
}
