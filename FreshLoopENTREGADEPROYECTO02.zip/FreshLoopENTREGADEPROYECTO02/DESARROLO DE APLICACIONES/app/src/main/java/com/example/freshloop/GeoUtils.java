package com.example.freshloop;

import android.location.Location;

public final class GeoUtils {
    private GeoUtils() { }
    public static double distanceKm(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[0] / 1000d;
    }
    public static String label(double km) { return String.format(java.util.Locale.US, "%.1f km aprox. · distancia en línea recta", km); }
}
