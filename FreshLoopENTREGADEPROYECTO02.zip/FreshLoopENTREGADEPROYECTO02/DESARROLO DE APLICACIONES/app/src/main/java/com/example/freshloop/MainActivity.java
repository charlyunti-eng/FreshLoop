package com.example.freshloop;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (FirebaseRepository.auth().getCurrentUser() != null) {
            String uid = FirebaseRepository.auth().getCurrentUser().getUid();
            FirebaseRepository.getUser(uid).addOnSuccessListener(profile -> {
                if (profile.exists() && profile.getString("nombre") != null && profile.getString("tipoUsuario") != null) {
                    getSharedPreferences("usuario", MODE_PRIVATE).edit()
                            .putString("nombre", profile.getString("nombre"))
                            .putString("tipo", profile.getString("tipoUsuario")).apply();
                    startActivity(new Intent(this, HomeActivity.class)); finish();
                }
            });
        }
        setContentView(R.layout.activity_main);
        findViewById(R.id.btnIngresar).setOnClickListener(v ->
                startActivity(new Intent(this, UserActivity.class).putExtra("auth_mode", "login")));
        findViewById(R.id.btnCrearCuenta).setOnClickListener(v ->
                startActivity(new Intent(this, UserActivity.class).putExtra("auth_mode", "register")));
    }
}
