package com.example.freshloop;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class SettingsActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_settings);
        findViewById(R.id.btnBackSettings).setOnClickListener(v -> finish());
        String uid = FirebaseAuth.getInstance().getUid(); if (uid == null) { finish(); return; }
        SharedPreferences preferences = getSharedPreferences("settings_" + uid, MODE_PRIVATE);
        Switch notifications = findViewById(R.id.swInAppNotifications);
        Switch location = findViewById(R.id.swLocationHints);
        notifications.setChecked(preferences.getBoolean("notifications", true));
        location.setChecked(preferences.getBoolean("locationHints", true));
        notifications.setOnCheckedChangeListener((button, checked) -> preferences.edit().putBoolean("notifications", checked).apply());
        location.setOnCheckedChangeListener((button, checked) -> preferences.edit().putBoolean("locationHints", checked).apply());
        String version = "1.0";
        try { version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
        ((TextView) findViewById(R.id.tvAppVersion)).setText("Versión " + version);
        findViewById(R.id.btnPasswordReset).setOnClickListener(v -> {
            if (FirebaseAuth.getInstance().getCurrentUser() == null || FirebaseAuth.getInstance().getCurrentUser().getEmail() == null) return;
            FirebaseAuth.getInstance().sendPasswordResetEmail(FirebaseAuth.getInstance().getCurrentUser().getEmail())
                    .addOnSuccessListener(x -> Toast.makeText(this, "Correo de restablecimiento enviado", Toast.LENGTH_LONG).show())
                    .addOnFailureListener(e -> Toast.makeText(this, "No se pudo enviar el correo", Toast.LENGTH_LONG).show());
        });
    }
}
