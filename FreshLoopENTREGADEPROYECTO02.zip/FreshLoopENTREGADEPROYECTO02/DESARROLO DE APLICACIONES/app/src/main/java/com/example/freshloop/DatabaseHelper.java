package com.example.freshloop;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "foodloop.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_FOODS = "alimentos";

    public DatabaseHelper(Context context) { super(context, DATABASE_NAME, null, DATABASE_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_FOODS + " (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nombre TEXT NOT NULL, descripcion TEXT NOT NULL, cantidad TEXT NOT NULL, " +
                "fechaVencimiento TEXT NOT NULL, precio TEXT NOT NULL, tipo TEXT NOT NULL, " +
                "direccion TEXT NOT NULL, publicador TEXT NOT NULL, estado TEXT NOT NULL)");
        insertExample(db, "Pan francés", "Pan recién horneado del día", "10 unidades", "09/09/2026", "Donación", "Donación", "Av. Principal 123", "Panadería San José");
        insertExample(db, "Ensalada fresca", "Ensalada preparada hoy", "3 porciones", "09/09/2026", "S/ 5.00", "Venta económica", "Jr. Los Olivos 456", "Restaurante El Buen Sabor");
        insertExample(db, "Empanadas", "Empanadas de pollo", "6 unidades", "10/09/2026", "S/ 2.00 c/u", "Venta económica", "Calle Central 789", "Cafetería Central");
    }

    private void insertExample(SQLiteDatabase db, String nombre, String descripcion, String cantidad,
                               String fecha, String precio, String tipo, String direccion, String publicador) {
        db.insert(TABLE_FOODS, null, makeValues(new Food(0, nombre, descripcion, cantidad, fecha,
                precio, tipo, direccion, publicador, "Disponible")));
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FOODS); onCreate(db);
    }

    public long addFood(Food food) {
        long id = getWritableDatabase().insert(TABLE_FOODS, null, makeValues(food));
        food.setId(id); return id;
    }

    public List<Food> getAllFoods() {
        List<Food> foods = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(TABLE_FOODS, null, null, null, null, null, "id DESC")) {
            while (cursor.moveToNext()) foods.add(fromCursor(cursor));
        }
        return foods;
    }

    public Food getFood(long id) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_FOODS, null, "id = ?",
                new String[]{String.valueOf(id)}, null, null, null)) {
            return cursor.moveToFirst() ? fromCursor(cursor) : null;
        }
    }

    public boolean reserveFood(long id) {
        ContentValues values = new ContentValues(); values.put("estado", "Reservado");
        return getWritableDatabase().update(TABLE_FOODS, values, "id = ? AND estado = ?",
                new String[]{String.valueOf(id), "Disponible"}) > 0;
    }

    private ContentValues makeValues(Food food) {
        ContentValues v = new ContentValues();
        v.put("nombre", food.getNombre()); v.put("descripcion", food.getDescripcion());
        v.put("cantidad", food.getCantidad()); v.put("fechaVencimiento", food.getFechaVencimiento());
        v.put("precio", food.getPrecio()); v.put("tipo", food.getTipo());
        v.put("direccion", food.getDireccion()); v.put("publicador", food.getPublicador());
        v.put("estado", food.getEstado()); return v;
    }

    private Food fromCursor(Cursor c) {
        return new Food(c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("nombre")),
                c.getString(c.getColumnIndexOrThrow("descripcion")), c.getString(c.getColumnIndexOrThrow("cantidad")),
                c.getString(c.getColumnIndexOrThrow("fechaVencimiento")), c.getString(c.getColumnIndexOrThrow("precio")),
                c.getString(c.getColumnIndexOrThrow("tipo")), c.getString(c.getColumnIndexOrThrow("direccion")),
                c.getString(c.getColumnIndexOrThrow("publicador")), c.getString(c.getColumnIndexOrThrow("estado")));
    }
}
