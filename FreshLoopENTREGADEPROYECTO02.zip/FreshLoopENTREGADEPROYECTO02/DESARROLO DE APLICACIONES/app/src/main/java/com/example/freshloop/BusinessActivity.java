package com.example.freshloop;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class BusinessActivity extends AppCompatActivity {
    private EditText name, description, address, zone, phone, hours;
    private Button save;
    private ProgressBar progress;
    private FirebaseFirestore db;
    private String uid;
    private double latitude = -11.9600, longitude = -77.0670;
    private boolean locationSelected;
    private ImageRepository.ProcessedImage selectedImage;
    private ActivityResultLauncher<String> imagePicker;
    private ActivityResultLauncher<Intent> locationPicker;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_business);
        name=findViewById(R.id.etBusinessName);description=findViewById(R.id.etBusinessDescription);address=findViewById(R.id.etBusinessAddress);zone=findViewById(R.id.etBusinessZone);phone=findViewById(R.id.etBusinessPhone);hours=findViewById(R.id.etBusinessHours);
        save=findViewById(R.id.btnSaveBusiness);progress=findViewById(R.id.progressBusiness);findViewById(R.id.btnBackBusiness).setOnClickListener(v->finish());
        db=FirebaseFirestore.getInstance();uid=FirebaseAuth.getInstance().getUid();if(uid==null){Toast.makeText(this,"Inicia sesión para registrar tu negocio",Toast.LENGTH_LONG).show();finish();return;}
        imagePicker=registerForActivityResult(new ActivityResultContracts.GetContent(),uri->{if(uri!=null)processImage(uri);});
        locationPicker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{if(result.getResultCode()==RESULT_OK&&result.getData()!=null){latitude=result.getData().getDoubleExtra("latitude",latitude);longitude=result.getData().getDoubleExtra("longitude",longitude);locationSelected=true;showCoordinates();}});
        findViewById(R.id.btnPickBusinessPhoto).setOnClickListener(v->imagePicker.launch("image/*"));
        findViewById(R.id.btnPickBusinessLocation).setOnClickListener(v->locationPicker.launch(new Intent(this,MapPickerActivity.class).putExtra("latitude",latitude).putExtra("longitude",longitude)));
        save.setOnClickListener(v->saveBusiness());showCoordinates();loadBusiness();
    }

    private void loadBusiness(){setBusy(true);db.collection("businesses").document(uid).get().addOnSuccessListener(document->{if(document.exists()){name.setText(document.getString("nombreNegocio"));description.setText(document.getString("descripcion"));address.setText(document.getString("direccion"));zone.setText(document.getString("zona"));phone.setText(document.getString("telefono"));hours.setText(document.getString("horario"));GeoPoint point=document.getGeoPoint("location");if(point!=null&&Boolean.TRUE.equals(document.getBoolean("locationConfirmed"))){latitude=point.getLatitude();longitude=point.getLongitude();locationSelected=true;}showCoordinates();Number version=(Number)document.get("imageVersion");ImageRepository.load(document.getString("imageId"),version==null?0:version.longValue(),(ImageView)findViewById(R.id.ivBusinessPhoto));save.setText("Actualizar negocio");}setBusy(false);if(getIntent().getBooleanExtra("pick_photo",false)){getIntent().removeExtra("pick_photo");findViewById(R.id.btnPickBusinessPhoto).performClick();}}).addOnFailureListener(error->{setBusy(false);Toast.makeText(this,"No se pudieron cargar los datos",Toast.LENGTH_SHORT).show();});}

    private void saveBusiness(){if(required(name)|required(address)|required(zone))return;Map<String,Object>data=new HashMap<>();data.put("nombreNegocio",text(name));data.put("descripcion",text(description));data.put("direccion",text(address));data.put("zona",text(zone));data.put("telefono",text(phone));data.put("horario",text(hours));if(locationSelected){data.put("location",new GeoPoint(latitude,longitude));data.put("locationConfirmed",true);data.put("locationSource","Seleccionada por el negocio");}data.put("uidUsuario",uid);setBusy(true);DocumentReference ref=db.collection("businesses").document(uid);Task<Void>task=selectedImage==null?ref.set(data,SetOptions.merge()):ImageRepository.setWithImage("business",uid,selectedImage,ref,data);task.addOnSuccessListener(v->{Toast.makeText(this,"Negocio guardado",Toast.LENGTH_SHORT).show();finish();}).addOnFailureListener(e->{setBusy(false);Toast.makeText(this,"No se pudo guardar el negocio",Toast.LENGTH_LONG).show();});}

    private void processImage(android.net.Uri uri){findViewById(R.id.btnPickBusinessPhoto).setEnabled(false);((TextView)findViewById(R.id.tvBusinessPhotoStatus)).setText("Procesando imagen…");ImageRepository.process(this,uri,new ImageRepository.Callback(){@Override public void onSuccess(ImageRepository.ProcessedImage image){selectedImage=image;((ImageView)findViewById(R.id.ivBusinessPhoto)).setImageBitmap(BitmapFactory.decodeByteArray(image.bytes,0,image.bytes.length));((TextView)findViewById(R.id.tvBusinessPhotoStatus)).setText("Lista para sincronizar · "+(image.bytes.length/1024)+" KiB");findViewById(R.id.btnPickBusinessPhoto).setEnabled(true);}@Override public void onError(Exception error){findViewById(R.id.btnPickBusinessPhoto).setEnabled(true);((TextView)findViewById(R.id.tvBusinessPhotoStatus)).setText("No se pudo procesar: "+error.getMessage());}});}
    private void showCoordinates(){((TextView)findViewById(R.id.tvBusinessCoordinates)).setText(locationSelected?String.format(Locale.US,"Ubicación confirmada: %.6f, %.6f",latitude,longitude):"Sin ubicación confirmada. Selecciona un punto para publicarlo.");}
    private boolean required(EditText field){if(text(field).isEmpty()){field.setError("Campo obligatorio");return true;}return false;}
    private String text(EditText field){return field.getText().toString().trim();}
    private void setBusy(boolean busy){progress.setVisibility(busy?View.VISIBLE:View.GONE);save.setEnabled(!busy);}
}
