package com.example.freshloop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class ConfirmReservationActivity extends AppCompatActivity {
    private String foodId;
    private int selected = 1;
    private int stock;
    private long unitPrice;
    private DocumentSnapshot food;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_confirm_reservation);
        foodId = getIntent().getStringExtra("food_doc_id"); if (foodId == null) { finish(); return; }
        findViewById(R.id.btnBackConfirm).setOnClickListener(v -> finish());
        findViewById(R.id.btnQuantityMinus).setOnClickListener(v -> { if (selected > 1) { selected--; updateSummary(); } });
        findViewById(R.id.btnQuantityPlus).setOnClickListener(v -> { if (selected < stock) { selected++; updateSummary(); } });
        findViewById(R.id.btnConfirmReservation).setOnClickListener(v -> reserve());
        FirebaseFirestore.getInstance().collection("foods").document(foodId).get().addOnSuccessListener(d -> { food = d; show(); }).addOnFailureListener(e -> { Toast.makeText(this, "No se pudo cargar el alimento", Toast.LENGTH_LONG).show(); finish(); });
    }

    private void show() {
        if (!ReservationRepository.isOfferable(food)) { Toast.makeText(this, "Este alimento no está publicado, disponible o vigente", Toast.LENGTH_LONG).show(); finish(); return; }
        stock = ReservationRepository.stock(food.get("quantity")); unitPrice = ReservationRepository.cents(food.getString("price"));
        if (stock < 1) { Toast.makeText(this, "No queda stock disponible", Toast.LENGTH_LONG).show(); finish(); return; }
        set(R.id.tvConfirmFood, food.getString("name")); set(R.id.tvConfirmBusiness, food.getString("publisher"));
        Number imageVersion = (Number) food.get("imageVersion");
        ImageRepository.load(food.getString("imageId"), imageVersion == null ? 0 : imageVersion.longValue(),
                (ImageView) findViewById(R.id.ivConfirmPhoto));
        set(R.id.tvConfirmAddress, safe(food.getString("address")) + " · " + safe(food.getString("zone")));
        String time = food.getString("pickupTime"); set(R.id.tvPickupLimit, safe(time).equals("No especificado") ? safe(food.getString("expiration")) : time + " · " + safe(food.getString("expiration")));
        updateSummary();
    }

    private void updateSummary() {
        set(R.id.tvSelectedQuantity, String.valueOf(selected)); set(R.id.tvAvailableStock, "máx. " + stock + " unidades");
        set(R.id.tvUnitPrice, unitPrice == 0 ? "Gratis" : ReservationRepository.money(unitPrice));
        set(R.id.tvReservationTotal, unitPrice == 0 ? "Gratis" : ReservationRepository.money(unitPrice * selected));
        findViewById(R.id.btnQuantityMinus).setEnabled(selected > 1); findViewById(R.id.btnQuantityPlus).setEnabled(selected < stock);
    }

    private void reserve() {
        setBusy(true);
        String client = getSharedPreferences("usuario", MODE_PRIVATE).getString("nombre", "Cliente");
        ReservationRepository.reserve(foodId, selected, client).addOnSuccessListener(ref -> {
            startActivity(new Intent(this, ReservationSuccessActivity.class).putExtra("reservation_id", ref.getId()).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)); finish();
        }).addOnFailureListener(e -> { setBusy(false); Toast.makeText(this, e.getMessage() == null ? "No se pudo reservar" : e.getMessage(), Toast.LENGTH_LONG).show(); });
    }

    private void setBusy(boolean busy) { findViewById(R.id.progressConfirm).setVisibility(busy ? View.VISIBLE : View.GONE); findViewById(R.id.btnConfirmReservation).setEnabled(!busy); }
    private void set(int id, String value) { ((TextView) findViewById(id)).setText(value == null ? "" : value); }
    private String safe(String value) { return value == null || value.trim().isEmpty() ? "No especificado" : value; }
}
