package com.example.freshloop;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.BitmapFactory;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class AddFoodActivity extends AppCompatActivity {
    private EditText nombre, descripcion, cantidad, fecha, precio, direccion, publicador, categoria, zona, horaLimite, precioOriginal;
    private ImageRepository.ProcessedImage selectedImage;
    private ActivityResultLauncher<String> imagePicker;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_add_food);
        nombre = findViewById(R.id.etNombreAlimento); descripcion = findViewById(R.id.etDescripcion);
        cantidad = findViewById(R.id.etCantidad); fecha = findViewById(R.id.etFecha);
        precio = findViewById(R.id.etPrecio); direccion = findViewById(R.id.etDireccion);
        horaLimite=findViewById(R.id.etHoraLimite);precioOriginal=findViewById(R.id.etPrecioOriginal);
        publicador = findViewById(R.id.etPublicador);
        categoria = findViewById(R.id.etCategoria); zona = findViewById(R.id.etZona);
        imagePicker = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> { if (uri != null) processImage(uri); });
        findViewById(R.id.btnPickFoodPhoto).setOnClickListener(v -> imagePicker.launch("image/*"));
        fecha.setOnClickListener(v->pickDate());horaLimite.setOnClickListener(v->pickTime());
        findViewById(R.id.btnBackAddFood).setOnClickListener(v -> finish());
        RadioGroup types = findViewById(R.id.rgTipo);
        types.setOnCheckedChangeListener((group, checkedId) -> {
            boolean sale = checkedId == R.id.rbVenta;
            precio.setEnabled(sale); precio.setAlpha(sale ? 1f : 0.45f);precioOriginal.setEnabled(sale);precioOriginal.setAlpha(sale?1f:0.45f);
            if (!sale) precio.setText("0"); else if ("0".equals(text(precio))) precio.setText("");
        });
        precio.setEnabled(false); precio.setAlpha(0.45f); precio.setText("0");
        precioOriginal.setEnabled(false);precioOriginal.setAlpha(0.45f);
        if (FirebaseRepository.auth().getCurrentUser() != null) {
            String uid = FirebaseRepository.auth().getCurrentUser().getUid();
            com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("businesses").document(uid).get()
                    .addOnSuccessListener(business -> {
                        if (!business.exists()) return;
                        publicador.setText(business.getString("nombreNegocio"));
                        direccion.setText(business.getString("direccion"));
                        zona.setText(business.getString("zona"));
                    });
        }
        findViewById(R.id.btnGuardarAlimento).setOnClickListener(v -> save());
    }
    private void save() {
        EditText[] required = {nombre, descripcion, cantidad, fecha, horaLimite, direccion, publicador, categoria, zona};
        for (EditText field : required) if (field.getText().toString().trim().isEmpty()) {
            field.setError("Campo obligatorio"); field.requestFocus(); return;
        }
        if (!text(fecha).matches("\\d{2}[-/]\\d{2}[-/]\\d{4}")) { fecha.setError("Usa dd-MM-yyyy"); fecha.requestFocus(); return; }
        RadioGroup types = findViewById(R.id.rgTipo);
        boolean donation = types.getCheckedRadioButtonId() == R.id.rbDonacion;
        int numericQuantity; try { numericQuantity=Integer.parseInt(text(cantidad)); } catch(Exception e){cantidad.setError("Usa una cantidad entera mayor que 0");return;} if(numericQuantity<=0){cantidad.setError("Cantidad mayor que 0");return;}
        String priceValue = donation ? "0" : text(precio);
        if (!donation && priceValue.isEmpty()) { precio.setError("Ingresa el precio"); precio.requestFocus(); return; }
        if (!donation) { try { if (Double.parseDouble(priceValue.replace(",", ".")) <= 0) throw new NumberFormatException(); } catch (NumberFormatException e) { precio.setError("Precio mayor que 0"); return; } }
        if(!donation&&!text(precioOriginal).isEmpty()){try{if(new java.math.BigDecimal(text(precioOriginal).replace(",",".")).compareTo(new java.math.BigDecimal(priceValue.replace(",",".")))<0)throw new NumberFormatException();}catch(Exception e){precioOriginal.setError("No puede ser menor al precio de oferta");return;}}
        try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("dd-MM-yyyy",java.util.Locale.ROOT);f.setLenient(false);java.util.Date d=f.parse(text(fecha).replace('/','-'));if(d==null||d.getTime()+86400000L<System.currentTimeMillis()){fecha.setError("Selecciona una fecha futura");return;}}catch(Exception e){fecha.setError("Usa dd-MM-yyyy");return;}
        Food food = new Food(0, text(nombre), text(descripcion), text(cantidad), text(fecha), priceValue,
                donation ? "Donación" : "Venta económica", text(direccion), text(publicador), "Disponible",donation?"":text(precioOriginal),text(horaLimite));
        if (FirebaseRepository.auth().getCurrentUser() == null) { Toast.makeText(this, "Sesión expirada", Toast.LENGTH_LONG).show(); return; }
        findViewById(R.id.btnGuardarAlimento).setEnabled(false);
        FirebaseRepository.saveFood(food, FirebaseRepository.auth().getCurrentUser().getUid(), text(zona), text(categoria), selectedImage)
                .addOnSuccessListener(ref -> {
                    try (DatabaseHelper db = new DatabaseHelper(this)) { db.addFood(food); }
                    Toast.makeText(this, "Alimento publicado", Toast.LENGTH_SHORT).show(); finish();
                }).addOnFailureListener(e -> {
                    findViewById(R.id.btnGuardarAlimento).setEnabled(true);
                    Toast.makeText(this, "No se pudo publicar", Toast.LENGTH_LONG).show();
                });
    }
    private void pickDate(){java.util.Calendar c=java.util.Calendar.getInstance();new android.app.DatePickerDialog(this,(v,y,m,d)->fecha.setText(String.format(java.util.Locale.ROOT,"%02d-%02d-%04d",d,m+1,y)),c.get(java.util.Calendar.YEAR),c.get(java.util.Calendar.MONTH),c.get(java.util.Calendar.DAY_OF_MONTH)).show();}
    private void pickTime(){java.util.Calendar c=java.util.Calendar.getInstance();new android.app.TimePickerDialog(this,(v,h,m)->horaLimite.setText(String.format(java.util.Locale.ROOT,"%02d:%02d",h,m)),c.get(java.util.Calendar.HOUR_OF_DAY),c.get(java.util.Calendar.MINUTE),true).show();}
    private void processImage(android.net.Uri uri) {
        findViewById(R.id.btnPickFoodPhoto).setEnabled(false);
        ((TextView) findViewById(R.id.tvFoodPhotoStatus)).setText("Procesando imagen…");
        ImageRepository.process(this, uri, new ImageRepository.Callback() {
            @Override public void onSuccess(ImageRepository.ProcessedImage image) {
                selectedImage = image; ((ImageView) findViewById(R.id.ivFoodPhotoPreview)).setImageBitmap(BitmapFactory.decodeByteArray(image.bytes, 0, image.bytes.length));
                ((TextView) findViewById(R.id.tvFoodPhotoStatus)).setText("Lista para sincronizar · " + (image.bytes.length / 1024) + " KiB");
                findViewById(R.id.btnPickFoodPhoto).setEnabled(true);
            }
            @Override public void onError(Exception error) { findViewById(R.id.btnPickFoodPhoto).setEnabled(true); ((TextView) findViewById(R.id.tvFoodPhotoStatus)).setText("No se pudo procesar: " + error.getMessage()); }
        });
    }
    private String text(EditText field) { return field.getText().toString().trim(); }
}
