package com.example.freshloop;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class FoodAdapter extends ArrayAdapter<Food> {
    public FoodAdapter(Context context, List<Food> foods) { super(context, 0, foods); }
    @Override public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView == null ? LayoutInflater.from(getContext()).inflate(R.layout.item_food, parent, false) : convertView;
        Food food = getItem(position);
        ((TextView) view.findViewById(R.id.tvItemNombre)).setText(food.getNombre());
        ((TextView) view.findViewById(R.id.tvItemPublicador)).setText(food.getPublicador());
        ((TextView) view.findViewById(R.id.tvItemCantidad)).setText("Cantidad: " + food.getCantidad());
        ((TextView) view.findViewById(R.id.tvItemTipo)).setText(food.getTipo());
        TextView status = view.findViewById(R.id.tvItemEstado); status.setText(food.getEstado());
        status.setTextColor(Color.parseColor("Reservado".equals(food.getEstado()) ? "#D97706" : "#2E7D32"));
        return view;
    }
}
