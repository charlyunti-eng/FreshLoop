package com.example.freshloop;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class ReservationDetailActivity extends AppCompatActivity {
    private String id;
    private DocumentSnapshot reservation;
    private String code = "";
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_reservation_detail);
        id = getIntent().getStringExtra("reservation_id"); if (id == null) { finish(); return; }
        findViewById(R.id.btnBackReservationDetail).setOnClickListener(v -> finish());
        findViewById(R.id.btnReservationMap).setOnClickListener(v -> startActivity(new Intent(this, MapActivity.class).putExtra("business_uid", reservation == null ? null : reservation.getString("uidNegocio"))));
        findViewById(R.id.btnReservationCopy).setOnClickListener(v -> { ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Código FreshLoop", code)); Toast.makeText(this, "Código copiado", Toast.LENGTH_SHORT).show(); });
        findViewById(R.id.btnReservationPrimaryAction).setOnClickListener(v -> confirmAction());
    }
    @Override protected void onResume() { super.onResume(); load(); }
    private void load() { FirebaseFirestore.getInstance().collection("reservations").document(id).get().addOnSuccessListener(r -> { reservation = r; show(); }).addOnFailureListener(e -> Toast.makeText(this, "No se pudo cargar la reserva", Toast.LENGTH_LONG).show()); }
    private void show() {
        if (reservation == null || !reservation.exists()) { finish(); return; }
        String role = getSharedPreferences("usuario", MODE_PRIVATE).getString("tipo", "Cliente"); boolean business = "Negocio".equals(role);
        String status = safe(reservation.getString("estadoReserva"), "Reservada"); code = safe(reservation.getString("codigo"), id.substring(0, Math.min(8, id.length())).toUpperCase());
        set(R.id.tvReservationDetailFood, safe(reservation.getString("nombreAlimento"), "Alimento")); set(R.id.tvReservationDetailStatus, status); set(R.id.tvReservationDetailCode, code);
        Number quantity = (Number) reservation.get("quantityReserved"), total = (Number) reservation.get("totalCents");
        String person = business ? "Cliente: " + safe(reservation.getString("nombreCliente"), "Cliente") : "Negocio: " + safe(reservation.getString("nombreNegocio"), "Negocio FreshLoop");
        set(R.id.tvReservationDetailInfo, person + "\nCantidad: " + (quantity == null ? 1 : quantity.intValue()) + "\nTotal: " + (total == null || total.longValue() == 0 ? "Gratis" : ReservationRepository.money(total.longValue())) + "\nRecojo: " + safe(reservation.getString("direccion"), "Sin dirección") + " · " + safe(reservation.getString("zona"), "Sin zona"));
        Button action = findViewById(R.id.btnReservationPrimaryAction);
        boolean modernReservation = reservation.get("quantityReserved") instanceof Number;
        boolean active = modernReservation && ("Confirmada".equals(status) || "Reservada".equals(status));
        action.setVisibility(active ? View.VISIBLE : View.GONE); action.setText(business ? "Marcar como entregada" : "Cancelar reserva");
    }
    private void confirmAction() {
        boolean business = "Negocio".equals(getSharedPreferences("usuario", MODE_PRIVATE).getString("tipo", "Cliente"));
        String title = business ? "Confirmar entrega" : "Cancelar reserva";
        String message = business ? "El alimento fue entregado al Cliente. Esta acción no descuenta stock nuevamente." : "¿Deseas cancelar? El stock se devolverá una sola vez si corresponde.";
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setNegativeButton("Volver", null).setPositiveButton("Confirmar", (d, w) -> {
            findViewById(R.id.btnReservationPrimaryAction).setEnabled(false);
            (business ? ReservationRepository.complete(id) : ReservationRepository.cancel(id)).addOnSuccessListener(v -> load()).addOnFailureListener(e -> { findViewById(R.id.btnReservationPrimaryAction).setEnabled(true); Toast.makeText(this, e.getMessage() == null ? "No se pudo actualizar" : e.getMessage(), Toast.LENGTH_LONG).show(); });
        }).show();
    }
    private void set(int viewId, String value) { ((TextView) findViewById(viewId)).setText(value); }
    private String safe(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value; }
}
