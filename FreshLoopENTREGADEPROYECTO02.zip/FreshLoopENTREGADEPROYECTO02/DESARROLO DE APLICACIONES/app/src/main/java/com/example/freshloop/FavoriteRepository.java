package com.example.freshloop;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public final class FavoriteRepository {
    private FavoriteRepository() { }

    private static String uid() { return FirebaseAuth.getInstance().getUid(); }

    public static Task<QuerySnapshot> getFavorites() {
        String uid = uid();
        if (uid == null) throw new IllegalStateException("Sesión requerida");
        return FirebaseFirestore.getInstance().collection("users").document(uid)
                .collection("favorites").get();
    }

    public static Task<Void> add(String foodId) {
        String uid = uid();
        if (uid == null) throw new IllegalStateException("Sesión requerida");
        Map<String, Object> data = new HashMap<>();
        data.put("foodId", foodId);
        data.put("uid", uid);
        data.put("createdAt", FieldValue.serverTimestamp());
        return FirebaseFirestore.getInstance().collection("users").document(uid)
                .collection("favorites").document(foodId).set(data);
    }

    public static Task<Void> remove(String foodId) {
        String uid = uid();
        if (uid == null) throw new IllegalStateException("Sesión requerida");
        return FirebaseFirestore.getInstance().collection("users").document(uid)
                .collection("favorites").document(foodId).delete();
    }
}
