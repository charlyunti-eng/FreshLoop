package com.example.freshloop;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.BitmapFactory;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import java.util.HashMap;
import java.util.Map;

public class EditFoodActivity extends AppCompatActivity {
    private EditText name, description, quantity, category, expiration, price, address, zone, originalPrice, pickupTime;
    private RadioGroup type;
    private DocumentReference foodRef;
    private String foodId;
    private ImageRepository.ProcessedImage selectedImage;
    private ActivityResultLauncher<String> imagePicker;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_edit_food);
        name=findViewById(R.id.etEditNombre); description=findViewById(R.id.etEditDescripcion);
        quantity=findViewById(R.id.etEditCantidad); category=findViewById(R.id.etEditCategoria);
        expiration=findViewById(R.id.etEditFecha); price=findViewById(R.id.etEditPrecio);
        originalPrice=findViewById(R.id.etEditPrecioOriginal);pickupTime=findViewById(R.id.etEditHoraLimite);
        address=findViewById(R.id.etEditDireccion); zone=findViewById(R.id.etEditZona); type=findViewById(R.id.rgEditTipo);
        imagePicker = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> { if (uri != null) processImage(uri); });
        findViewById(R.id.btnPickEditFoodPhoto).setOnClickListener(v -> imagePicker.launch("image/*"));
        expiration.setOnClickListener(v->pickDate());pickupTime.setOnClickListener(v->pickTime());
        findViewById(R.id.btnBackEditFood).setOnClickListener(v->finish());
        type.setOnCheckedChangeListener((group, checkedId)->{boolean sale=checkedId==R.id.rbEditVenta;price.setEnabled(sale);price.setAlpha(sale?1f:0.45f);originalPrice.setEnabled(sale);originalPrice.setAlpha(sale?1f:0.45f);if(!sale){price.setText("0");originalPrice.setText("");}});
        String id=getIntent().getStringExtra("food_doc_id");
        if(id==null){finish();return;} foodId=id;
        showValues(
                getIntent().getStringExtra("food_name"),
                getIntent().getStringExtra("food_description"),
                getIntent().getStringExtra("food_quantity"),
                getIntent().getStringExtra("food_category"),
                getIntent().getStringExtra("food_expiration"),
                getIntent().getStringExtra("food_type"),
                getIntent().getStringExtra("food_price"),
                getIntent().getStringExtra("food_address"),
                getIntent().getStringExtra("food_zone"));
        originalPrice.setText(getIntent().getStringExtra("food_original_price"));pickupTime.setText(getIntent().getStringExtra("food_pickup_time"));
        foodRef=com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("foods").document(id);
        foodRef.get().addOnSuccessListener(food->{
            if(!food.exists() || !FirebaseAuth.getInstance().getUid().equals(food.getString("uidNegocio"))){Toast.makeText(this,"No autorizado",Toast.LENGTH_LONG).show();finish();return;}
            showValues(food.getString("name"), food.getString("description"), String.valueOf(food.get("quantity")),
                    food.getString("category"), food.getString("expiration"), food.getString("type"),
                    food.getString("price"), food.getString("address"), food.getString("zone"));
            originalPrice.setText(food.getString("originalPrice"));pickupTime.setText(food.getString("pickupTime"));
            Number version=(Number)food.get("imageVersion"); ImageRepository.load(food.getString("imageId"),version==null?0:version.longValue(),(ImageView)findViewById(R.id.ivEditFoodPhoto));
        });
        findViewById(R.id.btnActualizarAlimento).setOnClickListener(v->save());
    }

    private void save(){
        EditText[] required={name,description,quantity,category,expiration,pickupTime,address,zone};
        for(EditText field:required)if(text(field).isEmpty()){field.setError("Campo obligatorio");field.requestFocus();return;}
        try{if(Integer.parseInt(text(quantity))<=0)throw new NumberFormatException();}catch(Exception e){quantity.setError("Cantidad entera mayor que 0");return;}
        if(!text(expiration).matches("\\d{2}[-/]\\d{2}[-/]\\d{4}")){expiration.setError("Usa dd-MM-yyyy");return;}
        boolean donation=type.getCheckedRadioButtonId()==R.id.rbEditDonacion;
        if(type.getCheckedRadioButtonId()==-1){Toast.makeText(this,"Selecciona modalidad",Toast.LENGTH_SHORT).show();return;}
        String priceValue=donation?"0":text(price);
        if(!donation){try{if(Double.parseDouble(priceValue.replace(",","."))<=0)throw new NumberFormatException();}catch(Exception e){price.setError("Precio mayor que 0");return;}}
        if(!donation&&!text(originalPrice).isEmpty()){try{if(new java.math.BigDecimal(text(originalPrice).replace(",",".")).compareTo(new java.math.BigDecimal(priceValue.replace(",",".")))<0)throw new NumberFormatException();}catch(Exception e){originalPrice.setError("No puede ser menor al precio de oferta");return;}}
        Map<String,Object> values=new HashMap<>(); values.put("name",text(name));values.put("description",text(description));
        values.put("quantity",ReservationRepository.stock(text(quantity)));values.put("category",text(category));values.put("expiration",text(expiration));
        values.put("type",donation?"Donación":"Venta económica");values.put("price",priceValue);values.put("address",text(address));values.put("zone",text(zone));
        values.put("originalPrice",donation?"":text(originalPrice));values.put("pickupTime",text(pickupTime));
        findViewById(R.id.btnActualizarAlimento).setEnabled(false);
        com.google.android.gms.tasks.Task<Void> updateTask = selectedImage == null ? foodRef.update(values) : ImageRepository.updateWithImage("food", foodId, selectedImage, foodRef, values);
        updateTask.addOnSuccessListener(v->{Toast.makeText(this,"Alimento actualizado",Toast.LENGTH_SHORT).show();finish();})
                .addOnFailureListener(e->{findViewById(R.id.btnActualizarAlimento).setEnabled(true);Toast.makeText(this,"No se pudo actualizar",Toast.LENGTH_LONG).show();});
    }
    private void pickDate(){java.util.Calendar c=java.util.Calendar.getInstance();new android.app.DatePickerDialog(this,(v,y,m,d)->expiration.setText(String.format(java.util.Locale.ROOT,"%02d-%02d-%04d",d,m+1,y)),c.get(java.util.Calendar.YEAR),c.get(java.util.Calendar.MONTH),c.get(java.util.Calendar.DAY_OF_MONTH)).show();}
    private void pickTime(){java.util.Calendar c=java.util.Calendar.getInstance();new android.app.TimePickerDialog(this,(v,h,m)->pickupTime.setText(String.format(java.util.Locale.ROOT,"%02d:%02d",h,m)),c.get(java.util.Calendar.HOUR_OF_DAY),c.get(java.util.Calendar.MINUTE),true).show();}
    private void processImage(android.net.Uri uri) {
        findViewById(R.id.btnPickEditFoodPhoto).setEnabled(false); ((TextView)findViewById(R.id.tvEditFoodPhotoStatus)).setText("Procesando imagen…");
        ImageRepository.process(this, uri, new ImageRepository.Callback() {
            @Override public void onSuccess(ImageRepository.ProcessedImage image) { selectedImage=image;((ImageView)findViewById(R.id.ivEditFoodPhoto)).setImageBitmap(BitmapFactory.decodeByteArray(image.bytes,0,image.bytes.length));((TextView)findViewById(R.id.tvEditFoodPhotoStatus)).setText("Nueva foto lista · "+(image.bytes.length/1024)+" KiB");findViewById(R.id.btnPickEditFoodPhoto).setEnabled(true); }
            @Override public void onError(Exception error) { findViewById(R.id.btnPickEditFoodPhoto).setEnabled(true);((TextView)findViewById(R.id.tvEditFoodPhotoStatus)).setText("No se pudo procesar: "+error.getMessage()); }
        });
    }

    private void showValues(String foodName, String foodDescription, String foodQuantity,
                            String foodCategory, String foodExpiration, String foodType,
                            String foodPrice, String foodAddress, String foodZone) {
        if (foodName == null) return;
        name.setText(foodName); description.setText(foodDescription); quantity.setText(foodQuantity);
        category.setText(foodCategory); expiration.setText(foodExpiration); price.setText(foodPrice);
        address.setText(foodAddress); zone.setText(foodZone);
        type.check("Donación".equals(foodType) ? R.id.rbEditDonacion : R.id.rbEditVenta);
    }
    private String text(EditText e){return e.getText().toString().trim();}
}
