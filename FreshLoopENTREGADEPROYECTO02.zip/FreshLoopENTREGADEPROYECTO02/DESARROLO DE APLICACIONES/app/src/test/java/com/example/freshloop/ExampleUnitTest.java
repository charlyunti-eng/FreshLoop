package com.example.freshloop;

import org.junit.Test;

import static org.junit.Assert.*;

public class ExampleUnitTest {
    @Test public void stock_acceptsFirestoreNumbersAndLegacyStrings() {
        assertEquals(4, ReservationRepository.stock(4L));
        assertEquals(3, ReservationRepository.stock("3"));
        assertEquals(2, ReservationRepository.stock("2.9"));
        assertEquals(0, ReservationRepository.stock(null));
    }

    @Test public void prices_useExactCents() {
        assertEquals(800L, ReservationRepository.cents("8.00"));
        assertEquals(1050L, ReservationRepository.cents("10,50"));
        assertEquals(0L, ReservationRepository.cents("Gratis"));
        assertEquals("S/ 10.50", ReservationRepository.money(1050));
    }

    @Test public void expiration_rejectsPastAndAcceptsFutureDates() {
        assertTrue(ReservationRepository.isExpired("01-01-2020"));
        assertFalse(ReservationRepository.isExpired("31-12-2099"));
        assertFalse(ReservationRepository.isExpired("31/12/2099"));
        assertFalse(ReservationRepository.isExpired("fecha-invalida"));
    }
}
